export type UserRole = 'admin' | 'interviewer' | 'candidate';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
}

export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH';

export interface Question {
  id: string;
  text: string;
  category: string;
  timeLimitSeconds: number;
}

export type FraudType = 
  | 'FACE_ABSENT'
  | 'MULTIPLE_FACES'
  | 'MOBILE_PHONE_DETECTED'
  | 'TAB_SWITCHED'
  | 'FULLSCREEN_EXIT'
  | 'LOOKING_AWAY'
  | 'HEAD_POSE_ABNORMAL'
  | 'VOICE_MULTI_SPEAKER'
  | 'VOICE_MUTED'
  | 'SCREEN_SHARE_STOPPED'
  | 'UNAUTHORIZED_OBJECT'
  | 'COPY_PASTE_ATTEMPT'
  | 'RIGHT_CLICK_ATTEMPT'
  | 'DEV_TOOLS_ATTEMPT';

export interface FraudViolation {
  id: string;
  interviewId: string;
  timestamp: string;
  type: FraudType;
  title: string;
  description: string;
  scorePenalty: number;
  confidenceScore: number;
  screenshotUrl?: string;
  actionTaken: string;
}

export interface EmotionStats {
  happy: number;
  neutral: number;
  angry: number;
  sad: number;
  fear: number;
  surprise: number;
  disgust: number;
  confused: number;
  stressed: number;
  nervous: number;
}

export interface EyeGazeStats {
  eyeContactPercentage: number;
  blinkCount: number;
  excessiveLookAwayCount: number;
  prolongedClosureCount: number;
}

export interface HeadPoseStats {
  forwardPercentage: number;
  turnedLeftCount: number;
  turnedRightCount: number;
  lookingDownCount: number;
}

export interface TranscriptSegment {
  id: string;
  speaker: 'Candidate' | 'Interviewer';
  timestamp: string;
  originalText: string;
  translatedText: string;
  language: string;
}

export interface InterviewSession {
  id: string;
  sessionId: string; // Encrypted / Unique room session ID
  title: string;
  candidateName: string;
  candidateEmail: string;
  interviewerName: string;
  interviewerEmail: string;
  jobRole: string;
  status: 'SCHEDULED' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED';
  scheduledTime: string;
  durationMinutes: number;
  questions: Question[];
  currentQuestionIndex: number;
  
  // Real-time proctoring metrics
  fraudScore: number; // 0 to 100
  riskLevel: RiskLevel;
  faceVisibilityPercent: number;
  cameraStatus: boolean;
  micStatus: boolean;
  screenShareStatus: boolean;
  fullscreenStatus: boolean;
  internetStatus: 'ONLINE' | 'UNSTABLE' | 'OFFLINE';
  
  // Accumulated data
  violations: FraudViolation[];
  emotions: EmotionStats;
  eyeGaze: EyeGazeStats;
  headPose: HeadPoseStats;
  transcript: TranscriptSegment[];
  
  // Post interview report
  aiReport?: AIReport;
  recordedVideoUrl?: string;
}

export interface AIReport {
  id: string;
  interviewId: string;
  generatedAt: string;
  candidateName: string;
  jobRole: string;
  overallFraudScore: number;
  riskClassification: RiskLevel;
  faceVisibilityPercent: number;
  eyeContactPercent: number;
  emotionBreakdown: EmotionStats;
  totalViolationsCount: number;
  violationsSummary: FraudViolation[];
  transcript: TranscriptSegment[];
  aiRecommendations: string[];
  technicalCompetencyScore: number;
  softSkillsScore: number;
  interviewerRemarks?: string;
  finalHiringDecision: 'RECOMMENDED' | 'NEEDS_REVIEW' | 'REJECT_SUSPECTED_FRAUD';
}
