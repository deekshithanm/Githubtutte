import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { LoginView } from './components/auth/LoginView';
import { AdminDashboard } from './components/dashboard/AdminDashboard';
import { InterviewerDashboard } from './components/dashboard/InterviewerDashboard';
import { CandidateDashboard } from './components/dashboard/CandidateDashboard';
import { GoogleMeetPreJoin } from './components/meet/GoogleMeetPreJoin';
import { GoogleMeetRoom } from './components/meet/GoogleMeetRoom';
import { AIReportModal } from './components/report/AIReportModal';
import { InterviewSession } from './types';

function MainApp() {
  const { user, isLoading } = useAuth();
  
  const [activeMeetSession, setActiveMeetSession] = useState<InterviewSession | null>(null);
  const [meetState, setMeetState] = useState<'none' | 'prejoin' | 'room'>('none');
  const [isHost, setIsHost] = useState(false);
  const [participantName, setParticipantName] = useState('');
  const [prejoinStreams, setPrejoinStreams] = useState<{ camStream: MediaStream } | undefined>();
  
  const [selectedReportSession, setSelectedReportSession] = useState<InterviewSession | null>(null);
  const [codeLookupError, setCodeLookupError] = useState<string | null>(null);

  // Check URL query parameter ?meet=sec-int-101 on initial load
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const meetCode = params.get('meet');
    if (meetCode) {
      fetch(`/api/interviews/code/${meetCode}`)
        .then((res) => res.json())
        .then((session) => {
          if (session && session.id) {
            setActiveMeetSession(session);
            setIsHost(user?.role === 'admin' || user?.role === 'interviewer');
            setMeetState('prejoin');
          }
        })
        .catch(() => {});
    }
  }, [user]);

  const handleJoinWithCode = async (code: string) => {
    setCodeLookupError(null);
    try {
      const res = await fetch(`/api/interviews/code/${code}`);
      const session = await res.json();
      if (!res.ok || !session.id) {
        alert('Meeting link or code not found. Please check and try again.');
        return;
      }
      setActiveMeetSession(session);
      setIsHost(user?.role === 'admin' || user?.role === 'interviewer');
      setMeetState('prejoin');
    } catch (err) {
      alert('Failed to connect to meeting room. Please check your internet connection.');
    }
  };

  const handleStartHostMeeting = (session: InterviewSession) => {
    setActiveMeetSession(session);
    setIsHost(true);
    setMeetState('prejoin');
  };

  const handleStartCandidateMeeting = (session: InterviewSession) => {
    setActiveMeetSession(session);
    setIsHost(false);
    setMeetState('prejoin');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center">
        <div className="text-center space-y-3">
          <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs text-slate-400 font-mono">Initializing Google Meet AI Interview Platform...</p>
        </div>
      </div>
    );
  }

  // Active Google Meet Pre-Join Room (Green Room)
  if (meetState === 'prejoin' && activeMeetSession) {
    return (
      <GoogleMeetPreJoin
        session={activeMeetSession}
        isHost={isHost}
        onJoinSuccess={(name, streams) => {
          setParticipantName(name);
          setPrejoinStreams(streams);
          setMeetState('room');
        }}
        onBack={() => {
          setMeetState('none');
          setActiveMeetSession(null);
        }}
      />
    );
  }

  // Active Google Meet Unified Meeting Room
  if (meetState === 'room' && activeMeetSession) {
    return (
      <GoogleMeetRoom
        session={activeMeetSession}
        participantName={participantName || user?.name || (isHost ? 'Interviewer (Host)' : 'Candidate Guest')}
        isHost={isHost}
        initialStreams={prejoinStreams}
        onEndInterview={(updatedSession) => {
          setMeetState('none');
          setActiveMeetSession(null);
          setSelectedReportSession(updatedSession);
        }}
      />
    );
  }

  if (!user) {
    return <LoginView onJoinWithCode={handleJoinWithCode} />;
  }

  return (
    <>
      {user.role === 'admin' && (
        <AdminDashboard
          onSelectReport={(session) => setSelectedReportSession(session)}
          onJoinRoom={handleStartHostMeeting}
        />
      )}

      {user.role === 'interviewer' && (
        <InterviewerDashboard
          onSelectReport={(session) => setSelectedReportSession(session)}
          onJoinRoom={handleStartHostMeeting}
        />
      )}

      {user.role === 'candidate' && (
        <CandidateDashboard
          onStartInterview={(session) => handleStartCandidateMeeting(session)}
        />
      )}

      {selectedReportSession && (
        <AIReportModal
          session={selectedReportSession}
          onClose={() => setSelectedReportSession(null)}
        />
      )}
    </>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
