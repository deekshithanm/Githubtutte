import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { socketClient } from '../../lib/socket';
import { InterviewSession, FraudViolation } from '../../types';
import { ShieldCheck, Video, AlertTriangle, Users, Search, RefreshCw, FileText, Camera, ShieldAlert, LogOut, Download, Share2 } from 'lucide-react';
import { ShareMeetLinkModal } from '../meet/ShareMeetLinkModal';

interface AdminDashboardProps {
  onSelectReport: (session: InterviewSession) => void;
  onJoinRoom: (session: InterviewSession) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onSelectReport, onJoinRoom }) => {
  const { user, logout } = useAuth();
  const [sessions, setSessions] = useState<InterviewSession[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [riskFilter, setRiskFilter] = useState<'ALL' | 'LOW' | 'MEDIUM' | 'HIGH'>('ALL');
  const [selectedViolationModal, setSelectedViolationModal] = useState<FraudViolation | null>(null);
  const [shareSession, setShareSession] = useState<InterviewSession | null>(null);

  const fetchSessions = async () => {
    try {
      const res = await fetch('/api/interviews');
      const data = await res.json();
      setSessions(data);
    } catch (err) {
      console.error('Failed to fetch sessions', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSessions();
    socketClient.connect();
    socketClient.subscribe('global_admin', 'admin');

    const unsubscribe = socketClient.addListener((data) => {
      if (data.type === 'fraud_update' || data.type === 'interview_created' || data.type === 'interview_ended') {
        fetchSessions();
      }
    });

    const interval = setInterval(fetchSessions, 5000);

    return () => {
      unsubscribe();
      clearInterval(interval);
    };
  }, []);

  const filteredSessions = sessions.filter((s) => {
    const matchesQuery = s.candidateName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.jobRole.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.sessionId.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesRisk = riskFilter === 'ALL' || s.riskLevel === riskFilter;
    return matchesQuery && matchesRisk;
  });

  // Calculate live global stats
  const totalInterviews = sessions.length;
  const highRiskCount = sessions.filter((s) => s.riskLevel === 'HIGH').length;
  const activeCount = sessions.filter((s) => s.status === 'IN_PROGRESS').length;
  const avgFraudScore = Math.round(
    sessions.reduce((acc, curr) => acc + curr.fraudScore, 0) / (totalInterviews || 1)
  );

  // Aggregate recent fraud events timeline across all interviews
  const allViolations: Array<FraudViolation & { candidateName: string; jobRole: string }> = [];
  sessions.forEach((s) => {
    s.violations.forEach((v) => {
      allViolations.push({
        ...v,
        candidateName: s.candidateName,
        jobRole: s.jobRole,
      });
    });
  });

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* Top Navigation Bar */}
      <header className="bg-slate-900 border-b border-slate-800 px-6 py-4 flex items-center justify-between sticky top-0 z-30">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-600/10 border border-blue-500/20 rounded-xl text-blue-400">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-white leading-tight">
              AI Interview Monitor
            </h1>
            <p className="text-xs text-slate-400">Enterprise Live Monitoring Portal</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 text-xs">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-slate-300 font-medium">Logged in as:</span>
            <span className="text-white font-bold">{user?.name} (Admin)</span>
          </div>

          <button
            onClick={logout}
            className="p-2 text-slate-400 hover:text-white bg-slate-950 border border-slate-800 rounded-xl hover:bg-slate-800 transition"
            title="Log out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Content Dashboard */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-6 space-y-6">
        {/* Top Metric Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex items-center gap-4">
            <div className="p-3 bg-blue-500/10 border border-blue-500/20 rounded-xl text-blue-400">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs text-slate-400 font-medium">Total Interviews</p>
              <p className="text-2xl font-bold text-white mt-0.5">{totalInterviews}</p>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex items-center gap-4">
            <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-emerald-400">
              <Video className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs text-slate-400 font-medium">Live Active Sessions</p>
              <p className="text-2xl font-bold text-white mt-0.5">{activeCount}</p>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex items-center gap-4">
            <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-red-400">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs text-slate-400 font-medium">High Risk Flagged</p>
              <p className="text-2xl font-bold text-white mt-0.5">{highRiskCount}</p>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex items-center gap-4">
            <div className="p-3 bg-purple-500/10 border border-purple-500/20 rounded-xl text-purple-400">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs text-slate-400 font-medium">Avg Fraud Score</p>
              <p className="text-2xl font-bold text-white mt-0.5">{avgFraudScore}/100</p>
            </div>
          </div>
        </div>

        {/* Filter & Search Bar */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="relative w-full sm:w-96">
            <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search candidate name, role or session ID..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2 pl-10 pr-4 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto">
            {(['ALL', 'LOW', 'MEDIUM', 'HIGH'] as const).map((level) => (
              <button
                key={level}
                onClick={() => setRiskFilter(level)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium transition ${
                  riskFilter === level
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white'
                }`}
              >
                {level === 'ALL' ? 'All Risk Levels' : `${level} Risk`}
              </button>
            ))}

            <button
              onClick={fetchSessions}
              className="p-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-400 hover:text-white transition ml-2"
              title="Refresh Sessions"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Live Candidates Monitoring Grid */}
        <div className="space-y-4">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Video className="w-4 h-4 text-blue-400" />
            Live Candidate Monitoring Grid
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredSessions.map((session) => (
              <div
                key={session.id}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-5 hover:border-slate-700 transition flex flex-col justify-between space-y-4 relative overflow-hidden"
              >
                {/* Risk Badge Header */}
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-mono text-slate-500 font-bold tracking-wider uppercase">
                      {session.sessionId}
                    </span>
                    <h3 className="text-sm font-bold text-white mt-0.5">{session.candidateName}</h3>
                    <p className="text-xs text-slate-400">{session.jobRole}</p>
                  </div>

                  <span
                    className={`px-2.5 py-1 rounded-full text-[10px] font-bold tracking-wider uppercase border ${
                      session.riskLevel === 'HIGH'
                        ? 'bg-red-500/10 text-red-400 border-red-500/30'
                        : session.riskLevel === 'MEDIUM'
                        ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                        : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                    }`}
                  >
                    {session.riskLevel} RISK ({session.fraudScore}%)
                  </span>
                </div>

                {/* Candidate Camera Stream Preview Box */}
                <div className="relative aspect-video bg-slate-950 rounded-xl border border-slate-800/80 overflow-hidden flex items-center justify-center group">
                  <div className="text-center p-4">
                    <Camera className="w-8 h-8 text-slate-700 mx-auto mb-2" />
                    <p className="text-xs text-slate-500">
                      {session.status === 'IN_PROGRESS'
                        ? 'Live AI Stream Encrypted'
                        : 'Session Scheduled / Waiting Room'}
                    </p>
                  </div>

                  {session.status === 'IN_PROGRESS' && (
                    <div className="absolute top-2 left-2 flex items-center gap-1.5 bg-red-600/90 text-white text-[10px] font-bold px-2 py-0.5 rounded-md uppercase tracking-wider animate-pulse">
                      <span className="w-1.5 h-1.5 bg-white rounded-full" />
                      LIVE PROCTOR
                    </div>
                  )}

                  <div className="absolute bottom-2 left-2 right-2 flex justify-between items-center text-[10px] text-slate-400 bg-slate-950/80 backdrop-blur-md px-2.5 py-1 rounded-lg border border-slate-800">
                    <span>Cam: {session.cameraStatus ? 'ON' : 'OFF'}</span>
                    <span>Mic: {session.micStatus ? 'ON' : 'OFF'}</span>
                    <span>Screen: {session.screenShareStatus ? 'ON' : 'OFF'}</span>
                  </div>
                </div>

                {/* Violations Count Ticker */}
                <div className="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-800">
                  <span>
                    Violations Flagged: <strong className="text-white">{session.violations.length}</strong>
                  </span>
                  <span>
                    Status: <strong className="text-blue-400">{session.status}</strong>
                  </span>
                </div>

                {/* Action Buttons */}
                <div className="space-y-2">
                  <button
                    onClick={() => setShareSession(session)}
                    className="w-full bg-slate-950 hover:bg-slate-800 text-blue-400 font-bold py-2 rounded-xl text-xs transition border border-blue-500/30 flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    Share Google Meet Link
                  </button>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => onJoinRoom(session)}
                      className="w-full bg-blue-600/10 hover:bg-blue-600 text-blue-400 hover:text-white border border-blue-500/30 font-bold py-2 rounded-xl text-xs transition flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Video className="w-3.5 h-3.5" />
                      Join as Host
                    </button>

                    <button
                      onClick={() => onSelectReport(session)}
                      className="w-full bg-slate-950 hover:bg-slate-800 text-slate-300 font-bold py-2 rounded-xl text-xs transition border border-slate-800 flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      Full Report
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Global Real-Time Fraud Incident Timeline */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-red-400" />
            Global Real-Time Anti-Cheating Violation Log
          </h2>

          <div className="divide-y divide-slate-800/80 max-h-96 overflow-y-auto">
            {allViolations.length === 0 ? (
              <p className="text-xs text-slate-500 py-6 text-center">
                No security violations detected across sessions yet.
              </p>
            ) : (
              allViolations.map((v, idx) => (
                <div key={v.id || idx} className="py-3 flex items-start justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-white">{v.candidateName}</span>
                      <span className="text-[10px] text-slate-500">({v.jobRole})</span>
                      <span className="text-[10px] text-slate-500 font-mono">• {v.timestamp}</span>
                    </div>
                    <p className="text-xs text-red-400 font-medium flex items-center gap-1.5">
                      <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                      {v.title}: {v.description}
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-red-400 bg-red-500/10 px-2 py-1 rounded-md border border-red-500/20">
                      +{v.scorePenalty} Penalty
                    </span>
                    {v.screenshotUrl && (
                      <button
                        onClick={() => setSelectedViolationModal(v)}
                        className="text-xs text-blue-400 hover:underline flex items-center gap-1 bg-slate-950 px-2 py-1 rounded-md border border-slate-800"
                      >
                        <Camera className="w-3 h-3" /> Snapshot
                      </button>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </main>

      {/* Screenshot Evidence Modal */}
      {selectedViolationModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 w-full max-w-lg shadow-2xl relative">
            <h3 className="text-sm font-bold text-white mb-1">
              Captured Evidence Screenshot
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              Candidate: {selectedViolationModal.candidateName} • Timestamp: {selectedViolationModal.timestamp}
            </p>

            <div className="bg-black rounded-xl overflow-hidden border border-slate-800 aspect-video mb-4">
              <img
                src={selectedViolationModal.screenshotUrl}
                alt="Violation Frame"
                className="w-full h-full object-contain"
              />
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs text-slate-300 space-y-1 mb-4">
              <p><strong>Violation Type:</strong> {selectedViolationModal.type}</p>
              <p><strong>Details:</strong> {selectedViolationModal.description}</p>
              <p><strong>AI Confidence Score:</strong> Math.round({selectedViolationModal.confidenceScore * 100})%</p>
            </div>

            <button
              onClick={() => setSelectedViolationModal(null)}
              className="w-full bg-slate-800 text-white font-medium py-2 rounded-xl text-xs"
            >
              Close Snapshot
            </button>
          </div>
        </div>
      )}

      {shareSession && (
        <ShareMeetLinkModal
          session={shareSession}
          onClose={() => setShareSession(null)}
          onJoinAsHost={() => {
            onJoinRoom(shareSession);
            setShareSession(null);
          }}
        />
      )}
    </div>
  );
};
