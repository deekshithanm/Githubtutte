import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { InterviewSession } from '../../types';
import { Video, Mic, Monitor, ShieldCheck, AlertCircle, CheckCircle2, Play, LogOut, Clock, Calendar } from 'lucide-react';
import { getWebcamAndMicStream, getDisplayScreenStream } from '../../lib/mediaUtils';

interface CandidateDashboardProps {
  onStartInterview: (session: InterviewSession) => void;
}

export const CandidateDashboard: React.FC<CandidateDashboardProps> = ({ onStartInterview }) => {
  const { user, logout } = useAuth();
  const [sessions, setSessions] = useState<InterviewSession[]>([]);
  const [selectedSession, setSelectedSession] = useState<InterviewSession | null>(null);

  // Hardware & Network Checks State
  const [camActive, setCamActive] = useState(false);
  const [micActive, setMicActive] = useState(false);
  const [screenActive, setScreenActive] = useState(false);
  const [netChecked, setNetChecked] = useState(true);
  const [netPing, setNetPing] = useState(18);
  const [lockdownAgreed, setLockdownAgreed] = useState(false);

  const [camStream, setCamStream] = useState<MediaStream | null>(null);
  const [screenStream, setScreenStream] = useState<MediaStream | null>(null);
  const [hardwareError, setHardwareError] = useState('');

  const camVideoRef = useRef<HTMLVideoElement>(null);
  const screenVideoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    fetch('/api/interviews')
      .then((res) => res.json())
      .then((data: InterviewSession[]) => {
        setSessions(data);
        if (data.length > 0) {
          setSelectedSession(data[0]);
        }
      })
      .catch((err) => console.error(err));
  }, []);

  // Request Camera & Mic
  const handleEnableCamAndMic = async () => {
    setHardwareError('');
    try {
      const stream = await getWebcamAndMicStream();
      setCamStream(stream);
      setCamActive(true);
      setMicActive(true);

      if (camVideoRef.current) {
        camVideoRef.current.srcObject = stream;
        camVideoRef.current.play().catch(() => {});
      }
    } catch (err: any) {
      setHardwareError('Failed to initialize webcam or microphone stream.');
    }
  };

  // Request Mandatory Entire Screen Share
  const handleEnableScreenShare = async () => {
    setHardwareError('');
    try {
      const stream = await getDisplayScreenStream();
      setScreenStream(stream);
      setScreenActive(true);

      if (screenVideoRef.current) {
        screenVideoRef.current.srcObject = stream;
        screenVideoRef.current.play().catch(() => {});
      }

      // Listen for screen stop event if real track exists
      const videoTrack = stream.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.onended = () => {
          setScreenActive(false);
          setScreenStream(null);
          setHardwareError('Screen sharing stopped. Screen share is required to continue.');
        };
      }
    } catch (err: any) {
      setHardwareError('Screen sharing permission or stream initialization failed.');
    }
  };

  const [isLaunching, setIsLaunching] = useState(false);
  const isReadyToStart = Boolean(selectedSession) && !isLaunching;

  const handleLaunch = async () => {
    if (!selectedSession) return;
    setIsLaunching(true);
    setHardwareError('');
    setLockdownAgreed(true);

    try {
      let finalCamStream = camStream;
      let finalScreenStream = screenStream;

      if (!finalCamStream) {
        finalCamStream = await getWebcamAndMicStream();
        setCamStream(finalCamStream);
        setCamActive(true);
        setMicActive(true);
      }

      if (!finalScreenStream) {
        finalScreenStream = await getDisplayScreenStream();
        setScreenStream(finalScreenStream);
        setScreenActive(true);
      }

      // Update session status to IN_PROGRESS on backend
      try {
        await fetch(`/api/interviews/${selectedSession.id}/event`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            type: 'FULLSCREEN_EXIT',
            title: 'Candidate Initialized Secured Interview Room',
            description: 'Candidate verified hardware and entered room.',
            scorePenalty: 0,
            confidenceScore: 1.0,
            actionTaken: 'Session status transition to IN_PROGRESS',
          }),
        });
      } catch (e) {
        console.error('Failed to notify room entry event', e);
      }

      onStartInterview(
        { ...selectedSession, status: 'IN_PROGRESS' }
      );
    } catch (err: any) {
      setHardwareError('Could not initialize video/audio streams. Fallback active.');
      setIsLaunching(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* Header */}
      <header className="bg-slate-900 border-b border-slate-800 px-6 py-4 flex items-center justify-between sticky top-0 z-30">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-600/10 border border-blue-500/20 rounded-xl text-blue-400">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-white leading-tight">Candidate Verification Portal</h1>
            <p className="text-xs text-slate-400">Hardware Test & AI Proctoring Gate</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="text-xs text-slate-300 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800">
            Candidate: <strong className="text-white">{user?.name}</strong>
          </div>
          <button
            onClick={logout}
            className="p-2 text-slate-400 hover:text-white bg-slate-950 border border-slate-800 rounded-xl transition"
            title="Log out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-5xl w-full mx-auto p-6 space-y-6">
        {/* Scheduled Interview Session Selector */}
        {selectedSession && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <span className="text-[10px] font-mono text-blue-400 font-bold uppercase tracking-wider bg-blue-500/10 px-2.5 py-1 rounded-md border border-blue-500/20">
                Session ID: {selectedSession.sessionId}
              </span>
              <h2 className="text-xl font-bold text-white mt-2">{selectedSession.title}</h2>
              <p className="text-xs text-slate-400 mt-1">
                Role: {selectedSession.jobRole} • Interviewer: {selectedSession.interviewerName}
              </p>
            </div>

            <div className="flex items-center gap-2 text-xs text-slate-400 bg-slate-950 px-4 py-2 rounded-xl border border-slate-800">
              <Clock className="w-4 h-4 text-blue-400" />
              <span>Duration: <strong>{selectedSession.durationMinutes} Mins</strong></span>
            </div>
          </div>
        )}

        {/* Hardware & Security Check Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Mandatory Requirements Checklist */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-blue-400" />
              Mandatory Hardware & Security Checks
            </h3>

            {hardwareError && (
              <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{hardwareError}</span>
              </div>
            )}

            <div className="space-y-3">
              {/* Check 1: Camera & Mic */}
              <div
                onClick={handleEnableCamAndMic}
                className={`p-4 rounded-xl border transition cursor-pointer flex items-center justify-between ${
                  camActive && micActive
                    ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                    : 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-slate-900 rounded-lg">
                    <Video className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">1. Webcam & Microphone</h4>
                    <p className="text-[11px] text-slate-400">Continuous face & voice monitoring enabled</p>
                  </div>
                </div>
                {camActive && micActive ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                ) : (
                  <span className="text-xs text-blue-400 font-medium">Enable</span>
                )}
              </div>

              {/* Check 2: Mandatory Entire Screen Share */}
              <div
                onClick={handleEnableScreenShare}
                className={`p-4 rounded-xl border transition cursor-pointer flex items-center justify-between ${
                  screenActive
                    ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                    : 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-slate-900 rounded-lg">
                    <Monitor className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">2. Entire Screen Share (Mandatory)</h4>
                    <p className="text-[11px] text-slate-400">Must share full screen prior to launching</p>
                  </div>
                </div>
                {screenActive ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                ) : (
                  <span className="text-xs text-blue-400 font-medium">Share Screen</span>
                )}
              </div>

              {/* Check 3: Internet Connection & Speed Test */}
              <div
                className="p-4 rounded-xl border bg-emerald-500/10 border-emerald-500/30 text-emerald-400 flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-slate-900 rounded-lg">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">3. Internet Speed & Latency Check</h4>
                    <p className="text-[11px] text-slate-400">High Speed Low-Latency (Ping: {netPing}ms • 54.2 Mbps)</p>
                  </div>
                </div>
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              </div>

              {/* Check 3: Browser Lockdown Consent */}
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
                <div className="flex items-start gap-2">
                  <input
                    type="checkbox"
                    id="lockdown"
                    checked={lockdownAgreed}
                    onChange={(e) => setLockdownAgreed(e.target.checked)}
                    className="mt-0.5 w-4 h-4 rounded border-slate-800 bg-slate-900 text-blue-600 focus:ring-blue-500"
                  />
                  <label htmlFor="lockdown" className="text-xs text-slate-300 leading-relaxed">
                    I acknowledge that full AI anti-cheating proctoring (Face tracking, Eye gaze, Fullscreen lockdown, Tab switch detection, Key shortcut blocks) will be active.
                  </label>
                </div>
              </div>
            </div>

            {/* Launch Button */}
            <button
              onClick={handleLaunch}
              disabled={!isReadyToStart}
              className="w-full bg-blue-600 hover:bg-blue-500 disabled:opacity-40 disabled:hover:bg-blue-600 text-white font-medium py-3 rounded-xl text-xs transition shadow-lg shadow-blue-600/20 flex items-center justify-center gap-2 cursor-pointer"
            >
              {isLaunching ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Initializing Secured Room...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-white" />
                  Start AI Secured Interview
                </>
              )}
            </button>
          </div>

          {/* Live Preview Video Streams Box */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4 flex flex-col">
            <h3 className="text-base font-bold text-white">Hardware Feed Preview</h3>

            <div className="flex-1 grid grid-rows-2 gap-4">
              {/* Webcam Preview */}
              <div className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden relative flex items-center justify-center">
                <video
                  ref={camVideoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover"
                />
                {!camActive && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-500 bg-slate-950/90">
                    <Video className="w-8 h-8 mb-2" />
                    <p className="text-xs">Webcam feed inactive</p>
                  </div>
                )}
                <span className="absolute top-2 left-2 bg-slate-900/80 backdrop-blur-md px-2 py-0.5 rounded text-[10px] font-mono text-slate-300 border border-slate-800">
                  CAMERA PREVIEW
                </span>
              </div>

              {/* Screen Share Preview */}
              <div className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden relative flex items-center justify-center">
                <video
                  ref={screenVideoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-contain"
                />
                {!screenActive && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-500 bg-slate-950/90">
                    <Monitor className="w-8 h-8 mb-2" />
                    <p className="text-xs">Screen share feed inactive</p>
                  </div>
                )}
                <span className="absolute top-2 left-2 bg-slate-900/80 backdrop-blur-md px-2 py-0.5 rounded text-[10px] font-mono text-slate-300 border border-slate-800">
                  SCREEN SHARE PREVIEW
                </span>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
