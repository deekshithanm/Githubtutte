import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { InterviewSession, Question } from '../../types';
import { Plus, Video, Calendar, Clock, FileText, ShieldAlert, LogOut, Search, User, Trash2, Share2, Copy } from 'lucide-react';
import { ShareMeetLinkModal } from '../meet/ShareMeetLinkModal';

interface InterviewerDashboardProps {
  onSelectReport: (session: InterviewSession) => void;
  onJoinRoom: (session: InterviewSession) => void;
}

export const InterviewerDashboard: React.FC<InterviewerDashboardProps> = ({ onSelectReport, onJoinRoom }) => {
  const { user, logout } = useAuth();
  const [sessions, setSessions] = useState<InterviewSession[]>([]);
  const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false);
  const [shareSession, setShareSession] = useState<InterviewSession | null>(null);

  // New Interview Form
  const [candidateName, setCandidateName] = useState('');
  const [candidateEmail, setCandidateEmail] = useState('');
  const [jobRole, setJobRole] = useState('Senior Full-Stack Engineer');
  const [questions, setQuestions] = useState<Question[]>([
    { id: 'q1', text: 'Explain how you structure full-stack React and Express applications for production.', category: 'Architecture', timeLimitSeconds: 240 },
    { id: 'q2', text: 'Describe how WebSockets handle low-latency real-time state synchronization.', category: 'Networking', timeLimitSeconds: 240 }
  ]);
  const [newQuestionText, setNewQuestionText] = useState('');

  const fetchSessions = async () => {
    try {
      const res = await fetch('/api/interviews');
      const data = await res.json();
      setSessions(data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchSessions();
  }, []);

  const handleAddQuestion = () => {
    if (!newQuestionText.trim()) return;
    setQuestions([
      ...questions,
      {
        id: 'q_' + Date.now(),
        text: newQuestionText.trim(),
        category: 'Custom Question',
        timeLimitSeconds: 300,
      },
    ]);
    setNewQuestionText('');
  };

  const handleRemoveQuestion = (id: string) => {
    setQuestions(questions.filter((q) => q.id !== id));
  };

  const handleScheduleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/interviews/schedule', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          candidateName,
          candidateEmail,
          interviewerName: user?.name || 'Dr. Aris Thorne',
          interviewerEmail: user?.email || 'interviewer@company.com',
          jobRole,
          questions,
          scheduledTime: new Date().toISOString(),
          durationMinutes: 45,
        }),
      });

      if (res.ok) {
        const createdSession = await res.json();
        setIsScheduleModalOpen(false);
        setCandidateName('');
        setCandidateEmail('');
        fetchSessions();
        setShareSession(createdSession);
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* Top Bar */}
      <header className="bg-slate-900 border-b border-slate-800 px-6 py-4 flex items-center justify-between sticky top-0 z-30">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-600/10 border border-blue-500/20 rounded-xl text-blue-400">
            <Video className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-white leading-tight">Interviewer Portal</h1>
            <p className="text-xs text-slate-400">Conduct AI-Secured Video Interviews</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <button
            onClick={() => setIsScheduleModalOpen(true)}
            className="bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium py-2 px-4 rounded-xl transition flex items-center gap-1.5 shadow-lg shadow-blue-600/20"
          >
            <Plus className="w-4 h-4" />
            Schedule New Interview
          </button>

          <button
            onClick={logout}
            className="p-2 text-slate-400 hover:text-white bg-slate-950 border border-slate-800 rounded-xl transition"
            title="Log out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Dashboard List */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-6 space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Calendar className="w-4 h-4 text-blue-400" />
            Assigned Interview Sessions
          </h2>
          <span className="text-xs text-slate-400">Showing {sessions.length} sessions</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sessions.map((s) => (
            <div
              key={s.id}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-5 hover:border-slate-700 transition space-y-4 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between mb-2">
                  <span className="text-[10px] font-mono text-slate-500 font-bold uppercase">
                    {s.sessionId}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase ${
                      s.status === 'IN_PROGRESS'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : s.status === 'COMPLETED'
                        ? 'bg-blue-500/10 text-blue-400 border border-blue-500/30'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {s.status}
                  </span>
                </div>

                <h3 className="text-base font-bold text-white">{s.candidateName}</h3>
                <p className="text-xs text-slate-400 mb-3">{s.jobRole}</p>

                <div className="space-y-1 text-xs text-slate-400 bg-slate-950 p-3 rounded-xl border border-slate-800/80">
                  <p className="flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-slate-500" />
                    <span>{s.candidateEmail}</span>
                  </p>
                  <p className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-slate-500" />
                    <span>Questions: {s.questions.length} • Duration: {s.durationMinutes}m</span>
                  </p>
                  <p className="flex items-center gap-1.5">
                    <ShieldAlert className="w-3.5 h-3.5 text-slate-500" />
                    <span>Fraud Score: <strong className="text-white">{s.fraudScore}%</strong> ({s.riskLevel} Risk)</span>
                  </p>
                </div>
              </div>

              <div className="space-y-2 pt-2">
                <button
                  onClick={() => setShareSession(s)}
                  className="w-full bg-slate-950 hover:bg-slate-800 text-blue-400 font-bold py-2 rounded-xl text-xs transition border border-blue-500/30 flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  Share Google Meet Link
                </button>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => onJoinRoom(s)}
                    className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-2 rounded-xl text-xs transition flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Video className="w-3.5 h-3.5" />
                    {s.status === 'IN_PROGRESS' ? 'Enter Room' : 'Join as Host'}
                  </button>

                  <button
                    onClick={() => onSelectReport(s)}
                    className="w-full bg-slate-950 hover:bg-slate-800 text-slate-300 font-bold py-2 rounded-xl text-xs transition border border-slate-800 flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    AI Report
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>

      {/* Schedule Interview Modal */}
      {isScheduleModalOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 w-full max-w-lg shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-white">Schedule AI Interview Session</h3>

            <form onSubmit={handleScheduleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs text-slate-300 font-medium mb-1">Candidate Full Name</label>
                <input
                  type="text"
                  required
                  value={candidateName}
                  onChange={(e) => setCandidateName(e.target.value)}
                  placeholder="e.g. Maya Lin"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2 px-3 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs text-slate-300 font-medium mb-1">Candidate Email</label>
                <input
                  type="email"
                  required
                  value={candidateEmail}
                  onChange={(e) => setCandidateEmail(e.target.value)}
                  placeholder="maya.lin@example.com"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2 px-3 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs text-slate-300 font-medium mb-1">Target Job Role</label>
                <input
                  type="text"
                  required
                  value={jobRole}
                  onChange={(e) => setJobRole(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2 px-3 text-xs text-white"
                />
              </div>

              {/* Interview Questions list */}
              <div>
                <label className="block text-xs text-slate-300 font-medium mb-1">Interview Questions ({questions.length})</label>
                <div className="space-y-2 mb-2 max-h-36 overflow-y-auto pr-1">
                  {questions.map((q, idx) => (
                    <div key={q.id} className="p-2 bg-slate-950 rounded-lg border border-slate-800 text-xs flex justify-between items-center">
                      <span className="text-slate-300 truncate">{idx + 1}. {q.text}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveQuestion(q.id)}
                        className="text-slate-500 hover:text-red-400 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>

                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newQuestionText}
                    onChange={(e) => setNewQuestionText(e.target.value)}
                    placeholder="Add custom question..."
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-xl py-1.5 px-3 text-xs text-white"
                  />
                  <button
                    type="button"
                    onClick={handleAddQuestion}
                    className="bg-slate-800 hover:bg-slate-700 text-white text-xs px-3 py-1.5 rounded-xl"
                  >
                    Add
                  </button>
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsScheduleModalOpen(false)}
                  className="flex-1 bg-slate-800 text-slate-300 text-xs py-2 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 hover:bg-blue-500 text-white text-xs py-2 rounded-xl font-medium"
                >
                  Create Session
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {shareSession && (
        <ShareMeetLinkModal
          session={shareSession}
          onClose={() => setShareSession(null)}
          onJoinAsHost={() => {
            onJoinRoom(shareSession);
            setShareSession(null);
          }}
        />
      )}
    </div>
  );
};
