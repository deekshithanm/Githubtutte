import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { getWebcamAndMicStream } from '../../lib/mediaUtils';
import { socketClient } from '../../lib/socket';
import { InterviewSession } from '../../types';
import { Video, VideoOff, Mic, MicOff, ShieldCheck, CheckCircle2, Clock, Sparkles, AlertCircle, ArrowRight } from 'lucide-react';

interface GoogleMeetPreJoinProps {
  session: InterviewSession;
  isHost: boolean;
  onJoinSuccess: (participantName: string, streams: { camStream: MediaStream }) => void;
  onBack: () => void;
}

export const GoogleMeetPreJoin: React.FC<GoogleMeetPreJoinProps> = ({
  session,
  isHost,
  onJoinSuccess,
  onBack,
}) => {
  const { user } = useAuth();
  const [candidateName, setCandidateName] = useState(
    user?.name || session.candidateName || 'Candidate Guest'
  );
  const candidateNameRef = useRef(candidateName);
  candidateNameRef.current = candidateName;
  
  const [camActive, setCamActive] = useState(true);
  const [micActive, setMicActive] = useState(true);
  const [camStream, setCamStream] = useState<MediaStream | null>(null);
  const camStreamRef = useRef<MediaStream | null>(null);
  const [hardwareError, setHardwareError] = useState<string | null>(null);

  const [isWaitingForHost, setIsWaitingForHost] = useState(false);
  const [isDenied, setIsDenied] = useState(false);

  const videoPreviewRef = useRef<HTMLVideoElement>(null);

  // Initialize hardware preview
  useEffect(() => {
    let stream: MediaStream | null = null;
    let isMounted = true;

    async function initMedia() {
      try {
        stream = await getWebcamAndMicStream();
        if (isMounted) {
          setCamStream(stream);
          camStreamRef.current = stream;
          if (videoPreviewRef.current) {
            videoPreviewRef.current.srcObject = stream;
            videoPreviewRef.current.play().catch(() => {});
          }
        }
      } catch (err: any) {
        if (isMounted) {
          setHardwareError('Camera/Microphone permission required for Google Meet call.');
        }
      }
    }

    initMedia();

    // Listen to WebSocket admit/deny events
    socketClient.connect();
    socketClient.subscribe(session.id, isHost ? 'interviewer' : 'candidate');

    const unsubscribe = socketClient.addListener((data) => {
      if (data.type === 'admit_candidate' && data.interviewId === session.id) {
        const activeStream = camStreamRef.current || stream;
        onJoinSuccess(candidateNameRef.current, activeStream ? { camStream: activeStream } : undefined as any);
      } else if (data.type === 'deny_candidate' && data.interviewId === session.id) {
        setIsWaitingForHost(false);
        setIsDenied(true);
      }
    });

    return () => {
      isMounted = false;
      unsubscribe();
    };
  }, [session.id]);

  // Handle Cam Toggle
  const toggleCam = () => {
    if (camStream) {
      camStream.getVideoTracks().forEach((track) => {
        track.enabled = !camActive;
      });
      setCamActive(!camActive);
    }
  };

  // Handle Mic Toggle
  const toggleMic = () => {
    if (camStream) {
      camStream.getAudioTracks().forEach((track) => {
        track.enabled = !micActive;
      });
      setMicActive(!micActive);
    }
  };

  const handleActionClick = () => {
    if (!camStream) return;

    if (isHost) {
      // Host joins instantly
      onJoinSuccess(user?.name || session.interviewerName || 'Interviewer Host', { camStream });
    } else {
      // Candidate asks to join waiting room
      setIsWaitingForHost(true);
      socketClient.sendJoinRequest(session.id, candidateName, user?.id || 'cand_' + Date.now());
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-4 font-sans relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-4xl bg-slate-900/90 backdrop-blur-2xl border border-slate-800 rounded-3xl p-6 md:p-8 shadow-2xl relative z-10 flex flex-col md:flex-row gap-8 items-center">
        {/* Left: Video Preview Box */}
        <div className="w-full md:w-1/2 space-y-4">
          <div className="aspect-video bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 relative shadow-inner flex items-center justify-center">
            {camActive ? (
              <video
                ref={videoPreviewRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="flex flex-col items-center gap-2 text-slate-500">
                <VideoOff className="w-12 h-12 stroke-[1.5]" />
                <p className="text-xs font-semibold">Camera is turned off</p>
              </div>
            )}

            {/* In-Preview Name Tag */}
            <div className="absolute bottom-3 left-3 bg-slate-950/80 backdrop-blur-md px-3 py-1 rounded-lg border border-slate-800 text-xs font-bold text-white flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              {candidateName || 'Guest'}
            </div>

            {/* Media Controls Floating Overlay */}
            <div className="absolute bottom-3 right-3 flex items-center gap-2">
              <button
                onClick={toggleMic}
                className={`p-2.5 rounded-xl border text-xs font-bold transition cursor-pointer ${
                  micActive
                    ? 'bg-slate-900/90 border-slate-700 text-slate-200 hover:bg-slate-800'
                    : 'bg-red-500/20 border-red-500/40 text-red-400'
                }`}
                title={micActive ? 'Mute Microphone' : 'Unmute Microphone'}
              >
                {micActive ? <Mic className="w-4 h-4 text-emerald-400" /> : <MicOff className="w-4 h-4" />}
              </button>

              <button
                onClick={toggleCam}
                className={`p-2.5 rounded-xl border text-xs font-bold transition cursor-pointer ${
                  camActive
                    ? 'bg-slate-900/90 border-slate-700 text-slate-200 hover:bg-slate-800'
                    : 'bg-red-500/20 border-red-500/40 text-red-400'
                }`}
                title={camActive ? 'Turn Off Camera' : 'Turn On Camera'}
              >
                {camActive ? <Video className="w-4 h-4 text-blue-400" /> : <VideoOff className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-400 bg-slate-950/60 px-4 py-2.5 rounded-xl border border-slate-800">
            <span className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              Microphone & Audio Check
            </span>
            <span className="text-emerald-400 font-bold">Ready</span>
          </div>
        </div>

        {/* Right: Meeting Info & Join Action */}
        <div className="w-full md:w-1/2 space-y-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 bg-blue-600/10 border border-blue-500/30 text-blue-400 text-xs font-bold px-3 py-1 rounded-full">
              <Sparkles className="w-3.5 h-3.5" />
              Google Meet Secured Interview Room
            </div>

            <h2 className="text-xl font-extrabold text-white tracking-tight">
              {session.jobRole}
            </h2>

            <p className="text-xs text-slate-400">
              Meeting Code: <span className="font-mono text-white font-bold">{session.sessionId}</span>
            </p>
          </div>

          <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800/80 space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-300">
              <span className="text-slate-400">Host (Interviewer):</span>
              <span className="font-bold text-white">{session.interviewerName}</span>
            </div>
            <div className="flex items-center justify-between text-xs text-slate-300">
              <span className="text-slate-400">Candidate:</span>
              <span className="font-bold text-white">{session.candidateName}</span>
            </div>
            <div className="flex items-center justify-between text-xs text-slate-300">
              <span className="text-slate-400">Duration:</span>
              <span className="font-bold text-white flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-blue-400" /> {session.durationMinutes} minutes
              </span>
            </div>
          </div>

          {!isHost && (
            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-300">Your Name</label>
              <input
                type="text"
                value={candidateName}
                onChange={(e) => setCandidateName(e.target.value)}
                placeholder="Enter your full name"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-blue-500"
              />
            </div>
          )}

          {hardwareError && (
            <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-xs text-red-400 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{hardwareError}</span>
            </div>
          )}

          {/* Waiting for Host State Banner */}
          {isWaitingForHost ? (
            <div className="p-4 bg-blue-600/10 border border-blue-500/30 rounded-2xl space-y-2 text-center">
              <div className="w-8 h-8 border-3 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto" />
              <h4 className="text-xs font-bold text-white">Asking to Join...</h4>
              <p className="text-[11px] text-slate-300">
                Someone in the call will let you in soon. Host: <strong className="text-blue-400">{session.interviewerName}</strong>
              </p>
            </div>
          ) : isDenied ? (
            <div className="p-4 bg-red-500/10 border border-red-500/30 rounded-2xl text-center space-y-2">
              <AlertCircle className="w-6 h-6 text-red-400 mx-auto" />
              <h4 className="text-xs font-bold text-red-400">Entry Declined by Host</h4>
              <p className="text-[11px] text-slate-300">The interviewer has declined this call entry request.</p>
              <button
                onClick={onBack}
                className="text-xs text-blue-400 hover:underline font-bold"
              >
                Return Home
              </button>
            </div>
          ) : (
            <div className="flex gap-3">
              <button
                onClick={onBack}
                className="px-4 py-3 bg-slate-950 border border-slate-800 hover:bg-slate-800 text-slate-300 text-xs font-bold rounded-xl transition cursor-pointer"
              >
                Cancel
              </button>

              <button
                onClick={handleActionClick}
                className="flex-1 bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 px-6 rounded-xl text-xs transition shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>{isHost ? 'Join Now (Host)' : 'Ask to Join'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
