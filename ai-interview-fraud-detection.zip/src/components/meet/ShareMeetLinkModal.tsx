import React, { useState } from 'react';
import { InterviewSession } from '../../types';
import { Copy, Check, Share2, Mail, MessageSquare, PhoneCall, X, Sparkles, ExternalLink } from 'lucide-react';

interface ShareMeetLinkModalProps {
  session: InterviewSession;
  onClose: () => void;
  onJoinAsHost?: () => void;
}

export const ShareMeetLinkModal: React.FC<ShareMeetLinkModalProps> = ({
  session,
  onClose,
  onJoinAsHost,
}) => {
  const [copied, setCopied] = useState(false);

  const meetingUrl = `${window.location.origin}/?meet=${session.sessionId}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(meetingUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  const shareText = `Here is your secure Google Meet AI Interview link for ${session.jobRole}:\n${meetingUrl}\n\nMeeting Code: ${session.sessionId}`;

  const handleWhatsApp = () => {
    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(shareText)}`, '_blank');
  };

  const handleEmail = () => {
    window.open(`mailto:${session.candidateEmail}?subject=${encodeURIComponent(`Google Meet Interview Link: ${session.jobRole}`)}&body=${encodeURIComponent(shareText)}`, '_blank');
  };

  const handleSMS = () => {
    window.open(`sms:?body=${encodeURIComponent(shareText)}`, '_blank');
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 z-50 font-sans">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative space-y-6 animate-in fade-in zoom-in duration-200">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-blue-600/10 border border-blue-500/20 rounded-xl">
              <Share2 className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Share Google Meet Link</h3>
              <p className="text-[11px] text-slate-400">Meeting Code: <strong className="text-white font-mono">{session.sessionId}</strong></p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-xl border border-transparent hover:border-slate-800 transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Meeting Link Field */}
        <div className="space-y-2">
          <label className="block text-xs font-bold text-slate-300">Secure Meeting Link</label>
          <div className="flex gap-2">
            <input
              type="text"
              readOnly
              value={meetingUrl}
              className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-blue-400 font-mono focus:outline-none select-all"
            />
            <button
              onClick={handleCopy}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                copied
                  ? 'bg-emerald-600 text-white'
                  : 'bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-600/30'
              }`}
            >
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'Copied!' : 'Copy'}</span>
            </button>
          </div>
        </div>

        {/* 1-Click Share Buttons */}
        <div className="space-y-2">
          <p className="text-xs font-bold text-slate-300">Quick Share Options</p>
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={handleWhatsApp}
              className="p-3 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-2xl text-xs text-emerald-400 font-bold flex flex-col items-center gap-1.5 transition cursor-pointer"
            >
              <MessageSquare className="w-5 h-5 text-emerald-400" />
              <span>WhatsApp</span>
            </button>

            <button
              onClick={handleEmail}
              className="p-3 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-2xl text-xs text-blue-400 font-bold flex flex-col items-center gap-1.5 transition cursor-pointer"
            >
              <Mail className="w-5 h-5 text-blue-400" />
              <span>Email Candidate</span>
            </button>

            <button
              onClick={handleSMS}
              className="p-3 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-2xl text-xs text-purple-400 font-bold flex flex-col items-center gap-1.5 transition cursor-pointer"
            >
              <PhoneCall className="w-5 h-5 text-purple-400" />
              <span>SMS</span>
            </button>
          </div>
        </div>

        {/* Candidate / Host Summary */}
        <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 text-xs space-y-1.5">
          <p className="text-slate-400">
            Candidate <strong className="text-white">{session.candidateName}</strong> will open this link to test hardware and ask to join.
          </p>
          <p className="text-slate-400">
            As the Host (<strong className="text-white">{session.interviewerName}</strong>), you will admit them when they enter the call.
          </p>
        </div>

        {onJoinAsHost && (
          <button
            onClick={onJoinAsHost}
            className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 rounded-xl text-xs transition shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 cursor-pointer"
          >
            <ExternalLink className="w-4 h-4" />
            Join Meeting Now as Host
          </button>
        )}
      </div>
    </div>
  );
};
