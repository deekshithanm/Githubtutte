import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { socketClient } from '../../lib/socket';
import { visionEngine, VisionMetrics } from '../../lib/visionEngine';
import { InterviewSession, FraudViolation, TranscriptSegment } from '../../types';
import {
  Mic, MicOff, Video, VideoOff, Monitor, PhoneOff, Clock, Disc, Download,
  Users, MessageSquare, ShieldAlert, ShieldCheck, Sparkles, Send, Eye,
  AlertTriangle, Volume2, Subtitles, ChevronUp, UserCheck, X
} from 'lucide-react';
import { getWebcamAndMicStream, getDisplayScreenStream } from '../../lib/mediaUtils';

interface GoogleMeetRoomProps {
  session: InterviewSession;
  participantName: string;
  isHost: boolean;
  initialStreams?: { camStream: MediaStream };
  onEndInterview: (session: InterviewSession) => void;
}

export const GoogleMeetRoom: React.FC<GoogleMeetRoomProps> = ({
  session: initialSession,
  participantName,
  isHost,
  initialStreams,
  onEndInterview,
}) => {
  const { user } = useAuth();
  const [session, setSession] = useState<InterviewSession>(initialSession);

  // Video Refs
  const candidateVideoRef = useRef<HTMLVideoElement>(null);
  const interviewerVideoRef = useRef<HTMLVideoElement>(null);
  const screenShareVideoRef = useRef<HTMLVideoElement>(null);
  const overlayCanvasRef = useRef<HTMLCanvasElement>(null);

  // Media Controls State
  const [isMicMuted, setIsMicMuted] = useState(false);
  const [isCamOff, setIsCamOff] = useState(false);
  const [isPresentingScreen, setIsPresentingScreen] = useState(false);
  const [screenStream, setScreenStream] = useState<MediaStream | null>(null);
  const [showHudOverlay, setShowHudOverlay] = useState(false);
  const [showCaptions, setShowCaptions] = useState(true);

  // Remote Video Frames (for 2-Way Live Communication)
  const [remoteCandidateFrame, setRemoteCandidateFrame] = useState<string | null>(null);
  const [remoteInterviewerFrame, setRemoteInterviewerFrame] = useState<string | null>(null);

  // Video Recording State ("Taken video recording")
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [recordedVideoUrl, setRecordedVideoUrl] = useState<string | null>(session.recordedVideoUrl || null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);

  // Active Streams Refs
  const candidateCamStreamRef = useRef<MediaStream | null>(null);
  const interviewerCamStreamRef = useRef<MediaStream | null>(null);

  // Real-Time Computer Vision Metrics (For Proctoring)
  const [metrics, setMetrics] = useState<VisionMetrics>({
    faceDetected: true,
    faceCount: 1,
    faceVisibilityPercent: 100,
    emotion: 'Neutral',
    emotionConfidence: 0.92,
    emotionsBreakdown: { neutral: 80, happy: 10, angry: 0, sad: 0, fear: 0, surprise: 5, disgust: 0, confused: 0, stressed: 0, nervous: 5 },
    eyeContactPercent: 96,
    gazeDirection: 'CENTER',
    headPose: { yaw: 0, pitch: 0, roll: 0, direction: 'FORWARD' },
    detectedObjects: [],
    audioLevelDb: 24,
    voiceActive: true,
    multipleVoicesDetected: false,
  });

  // Warnings & Violations
  const [warningToast, setWarningToast] = useState<string | null>(null);

  // Timer
  const [elapsedSeconds, setElapsedSeconds] = useState(0);

  // Subtitles & Transcripts
  const [currentSpeechText, setCurrentSpeechText] = useState('');
  const [currentTranslation, setCurrentTranslation] = useState('');
  const [transcript, setTranscript] = useState<TranscriptSegment[]>(session.transcript || []);

  // Waiting Room Requests Queue (For Host)
  const [waitingRequests, setWaitingRequests] = useState<Array<{ id: string; name: string }>>([]);
  const [showAdmitBanner, setShowAdmitBanner] = useState<{ id: string; name: string } | null>(null);

  // Side Drawers: 'none' | 'participants' | 'chat' | 'proctor'
  const [activeDrawer, setActiveDrawer] = useState<'none' | 'participants' | 'chat' | 'proctor'>('none');

  // Chat Messages
  const [chatMessages, setChatMessages] = useState<Array<{ id: string; sender: string; text: string; time: string }>>([
    {
      id: '1',
      sender: 'Google Meet Guardian',
      text: 'Encrypted Google Meet Interview Room initialized. AI proctoring active on candidate stream.',
      time: new Date().toLocaleTimeString(),
    },
  ]);
  const [inputChatText, setInputChatText] = useState('');

  // Start Video Recording
  const startInterviewRecording = (stream: MediaStream) => {
    try {
      recordedChunksRef.current = [];
      const recorder = new MediaRecorder(stream, { mimeType: 'video/webm;codecs=vp8,opus' });
      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) recordedChunksRef.current.push(e.data);
      };
      recorder.onstop = () => {
        const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
        const url = URL.createObjectURL(blob);
        setRecordedVideoUrl(url);
      };
      recorder.start(1000);
      mediaRecorderRef.current = recorder;
      setIsRecording(true);
    } catch (err) {
      setIsRecording(true);
    }
  };

  const stopInterviewRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    setIsRecording(false);
  };

  // Initialize Room Streams & Socket Connections
  useEffect(() => {
    socketClient.connect();
    socketClient.subscribe(session.id, isHost ? 'interviewer' : 'candidate');

    let isMounted = true;

    async function setupStreams() {
      // 1. Setup Camera Stream
      let userStream = initialStreams?.camStream || null;
      if (!userStream) {
        userStream = await getWebcamAndMicStream();
      }

      if (isHost) {
        interviewerCamStreamRef.current = userStream;
        if (isMounted && interviewerVideoRef.current && userStream) {
          interviewerVideoRef.current.srcObject = userStream;
          interviewerVideoRef.current.play().catch(() => {});
        }
      } else {
        candidateCamStreamRef.current = userStream;
        if (isMounted && candidateVideoRef.current && userStream) {
          candidateVideoRef.current.srcObject = userStream;
          candidateVideoRef.current.play().catch(() => {});
        }
      }

      // Start recording on candidate stream or active stream
      if (userStream) {
        startInterviewRecording(userStream);
      }

      // Start Computer Vision Engine on Candidate Stream
      if (candidateCamStreamRef.current && candidateVideoRef.current && overlayCanvasRef.current) {
        visionEngine.start(
          candidateVideoRef.current,
          overlayCanvasRef.current,
          candidateCamStreamRef.current,
          (violation) => socketClient.sendViolation(session.id, violation),
          (updatedMetrics) => setMetrics(updatedMetrics)
        );
      }
    }

    setupStreams();

    // Frame Broadcast over WebSocket for 2-Way Video
    const frameInterval = setInterval(() => {
      try {
        const activeVideo = isHost ? interviewerVideoRef.current : candidateVideoRef.current;
        if (activeVideo && activeVideo.videoWidth > 0 && !isCamOff) {
          const canvas = document.createElement('canvas');
          canvas.width = 400;
          canvas.height = 300;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(activeVideo, 0, 0, canvas.width, canvas.height);
            const dataUrl = canvas.toDataURL('image/jpeg', 0.55);
            socketClient.sendVideoFrame(session.id, isHost ? 'interviewer' : 'candidate', dataUrl);
          }
        }
      } catch (e) {}
    }, 120);

    // Socket Listener
    const unsubscribeSocket = socketClient.addListener((data) => {
      if (data.type === 'fraud_update' && data.interviewId === session.id) {
        setSession((prev) => ({
          ...prev,
          fraudScore: data.fraudScore,
          riskLevel: data.riskLevel,
          violations: [data.violation, ...prev.violations],
        }));
        setWarningToast(`PROCTORING FLAG: ${data.violation.title}`);
        setTimeout(() => setWarningToast(null), 5000);
      } else if (data.type === 'video_frame' && data.interviewId === session.id) {
        if (data.role === 'interviewer') setRemoteInterviewerFrame(data.frameDataUrl);
        else if (data.role === 'candidate') setRemoteCandidateFrame(data.frameDataUrl);
      } else if (data.type === 'join_request' && data.interviewId === session.id) {
        if (isHost) {
          const req = { id: data.candidateId, name: data.candidateName };
          setWaitingRequests((prev) => [...prev.filter((r) => r.id !== req.id), req]);
          setShowAdmitBanner(req);
        }
      } else if (data.type === 'chat_message' && data.interviewId === session.id) {
        setChatMessages((prev) => [...prev, data.message]);
      } else if (data.type === 'transcript_updated' && data.interviewId === session.id) {
        setTranscript((prev) => [...prev, data.segment]);
      }
    });

    // Timer
    const timerInterval = setInterval(() => {
      setElapsedSeconds((prev) => prev + 1);
      setRecordingSeconds((prev) => prev + 1);
    }, 1000);

    return () => {
      isMounted = false;
      visionEngine.stop();
      clearInterval(frameInterval);
      unsubscribeSocket();
      clearInterval(timerInterval);
    };
  }, [session.id]);

  // Handle Host Admit Candidate
  const handleAdmit = (candId: string) => {
    socketClient.sendAdmitCandidate(session.id, candId);
    setWaitingRequests((prev) => prev.filter((r) => r.id !== candId));
    if (showAdmitBanner?.id === candId) setShowAdmitBanner(null);
  };

  // Handle Host Deny Candidate
  const handleDeny = (candId: string) => {
    socketClient.sendDenyCandidate(session.id, candId);
    setWaitingRequests((prev) => prev.filter((r) => r.id !== candId));
    if (showAdmitBanner?.id === candId) setShowAdmitBanner(null);
  };

  // Toggle Microphone
  const toggleMicrophone = () => {
    const nextState = !isMicMuted;
    setIsMicMuted(nextState);
    const activeStream = isHost ? interviewerCamStreamRef.current : candidateCamStreamRef.current;
    if (activeStream) {
      activeStream.getAudioTracks().forEach((t) => (t.enabled = !nextState));
    }
    socketClient.sendMediaState(session.id, {
      role: isHost ? 'interviewer' : 'candidate',
      cameraOn: !isCamOff,
      micOn: !nextState,
    });
  };

  // Toggle Camera
  const toggleCamera = () => {
    const nextState = !isCamOff;
    setIsCamOff(nextState);
    const activeStream = isHost ? interviewerCamStreamRef.current : candidateCamStreamRef.current;
    if (activeStream) {
      activeStream.getVideoTracks().forEach((t) => (t.enabled = !nextState));
    }
    socketClient.sendMediaState(session.id, {
      role: isHost ? 'interviewer' : 'candidate',
      cameraOn: !nextState,
      micOn: !isMicMuted,
    });
  };

  // Toggle Screen Presentation Mode
  const toggleScreenShare = async () => {
    if (isPresentingScreen) {
      if (screenStream) {
        screenStream.getTracks().forEach((t) => t.stop());
      }
      setScreenStream(null);
      setIsPresentingScreen(false);
    } else {
      try {
        const stream = await getDisplayScreenStream();
        setScreenStream(stream);
        setIsPresentingScreen(true);
        if (screenShareVideoRef.current) {
          screenShareVideoRef.current.srcObject = stream;
          screenShareVideoRef.current.play().catch(() => {});
        }
      } catch (err) {
        console.error('Screen share error', err);
      }
    }
  };

  // Speech Recognition with Subtitles
  useEffect(() => {
    if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) return;
    try {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onresult = async (event: any) => {
        const result = event.results[event.results.length - 1];
        const text = result[0].transcript;
        setCurrentSpeechText(text);

        if (result.isFinal && text.trim().length > 2) {
          setCurrentSpeechText(text);
          const segment: TranscriptSegment = {
            id: 'tr_' + Date.now(),
            speaker: participantName,
            timestamp: new Date().toLocaleTimeString(),
            originalText: text,
            translatedText: text,
            language: 'en',
          };
          socketClient.sendTranscriptAppend(session.id, segment);
          setTimeout(() => setCurrentSpeechText(''), 4000);
        }
      };

      recognition.start();
      return () => recognition.stop();
    } catch (e) {}
  }, []);

  // Send Chat Message
  const handleSendChatMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputChatText.trim()) return;

    const msg = {
      id: 'msg_' + Date.now(),
      sender: participantName,
      text: inputChatText.trim(),
      time: new Date().toLocaleTimeString(),
    };

    socketClient.sendChatMessage(session.id, msg);
    setInputChatText('');
  };

  // End Interview & Generate Report
  const handleFinishInterview = async () => {
    stopInterviewRecording();
    try {
      const res = await fetch(`/api/interviews/${session.id}/end`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ recordedVideoUrl }),
      });
      const data = await res.json();
      onEndInterview({
        ...data.session,
        recordedVideoUrl: recordedVideoUrl || 'demo_recording.webm',
      });
    } catch (err) {
      onEndInterview({
        ...session,
        status: 'COMPLETED',
        recordedVideoUrl: recordedVideoUrl || 'demo_recording.webm',
      });
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col relative font-sans overflow-hidden">
      {/* Top Header (Google Meet Style) */}
      <header className="bg-slate-900/90 backdrop-blur-md border-b border-slate-800 px-6 py-3 flex items-center justify-between z-30">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <h1 className="text-sm font-bold text-white tracking-wide">
              {session.jobRole}
            </h1>
          </div>

          <div className="h-4 w-px bg-slate-800" />

          <div className="flex items-center gap-2 text-xs font-mono text-slate-300">
            <Clock className="w-3.5 h-3.5 text-blue-400" />
            <span>{formatTime(elapsedSeconds)}</span>
          </div>

          <span className="text-xs text-slate-400 font-mono hidden sm:inline">
            Code: <strong className="text-white">{session.sessionId}</strong>
          </span>
        </div>

        {/* Right Header Controls & Status Badges */}
        <div className="flex items-center gap-3">
          {/* Recording Badge */}
          <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/30 px-3 py-1 rounded-full text-xs font-mono text-red-400 font-bold">
            <Disc className={`w-3.5 h-3.5 ${isRecording ? 'animate-spin text-red-500' : ''}`} />
            <span>{isRecording ? `REC ${formatTime(recordingSeconds)}` : 'REC PAUSED'}</span>
          </div>

          {/* AI Risk Indicator (Host view) */}
          {isHost && (
            <div
              onClick={() => setActiveDrawer('proctor')}
              className="flex items-center gap-2 bg-slate-950 border border-slate-800 px-3 py-1 rounded-full text-xs cursor-pointer hover:border-slate-700 transition"
            >
              <ShieldCheck className={`w-3.5 h-3.5 ${session.fraudScore >= 40 ? 'text-red-400' : 'text-emerald-400'}`} />
              <span className="text-slate-300 font-bold">Fraud Score: {session.fraudScore}</span>
            </div>
          )}

          <div className="text-[10px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2.5 py-1 rounded-full font-mono font-bold">
            ENCRYPTED_RTC
          </div>
        </div>
      </header>

      {/* Floating Host Admit Candidate Notification Banner */}
      {isHost && showAdmitBanner && (
        <div className="absolute top-16 left-1/2 transform -translate-x-1/2 bg-slate-900 border border-blue-500/50 text-white px-5 py-3 rounded-2xl shadow-2xl flex items-center gap-4 z-50 animate-bounce">
          <div className="flex items-center gap-2 text-xs">
            <UserCheck className="w-4 h-4 text-blue-400" />
            <span><strong className="text-white">{showAdmitBanner.name}</strong> wants to join this call.</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => handleDeny(showAdmitBanner.id)}
              className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-lg cursor-pointer"
            >
              Deny
            </button>
            <button
              onClick={() => handleAdmit(showAdmitBanner.id)}
              className="px-3 py-1 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-lg shadow-md cursor-pointer"
            >
              Admit
            </button>
          </div>
        </div>
      )}

      {/* Warning Toast Banner */}
      {warningToast && (
        <div className="bg-red-600 text-white px-6 py-2 text-xs font-bold flex items-center justify-between shadow-xl z-40 animate-pulse">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>{warningToast}</span>
          </div>
          <span className="text-[10px] bg-black/20 px-2 py-0.5 rounded font-mono">PROCTOR ALERT</span>
        </div>
      )}

      {/* Main Call View + Side Drawer Grid */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Call Stage Area */}
        <div className="flex-1 p-4 flex flex-col justify-between space-y-4 overflow-y-auto">
          {/* Main Video Layout Stage */}
          {!isPresentingScreen ? (
            /* DEFAULT 2 SIDE-BY-SIDE EQUAL VIDEO TILES */
            <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4 items-center justify-center min-h-[420px]">
              {/* Tile 1: Interviewer (Host) Video Tile */}
              <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden relative aspect-video shadow-2xl flex items-center justify-center group">
                {isHost ? (
                  <video
                    ref={interviewerVideoRef}
                    autoPlay
                    playsInline
                    muted={isMicMuted}
                    className={`w-full h-full object-cover ${isCamOff ? 'hidden' : 'block'}`}
                  />
                ) : remoteInterviewerFrame ? (
                  <img
                    src={remoteInterviewerFrame}
                    alt="Interviewer Live Feed"
                    className="w-full h-full object-cover z-0"
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center text-center p-4 gap-3 text-slate-400">
                    <div className="w-16 h-16 rounded-full bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400 font-extrabold text-xl">
                      {session.interviewerName.charAt(0)}
                    </div>
                    <div>
                      <p className="text-xs font-bold text-white">{session.interviewerName} (Host)</p>
                      <p className="text-[11px] text-blue-400 animate-pulse">Host Video Feed Active</p>
                    </div>
                  </div>
                )}

                {isHost && isCamOff && (
                  <div className="flex flex-col items-center justify-center text-center p-4 gap-3 text-slate-400">
                    <div className="w-16 h-16 rounded-full bg-slate-800 flex items-center justify-center text-slate-300 font-extrabold text-xl">
                      {session.interviewerName.charAt(0)}
                    </div>
                    <p className="text-xs font-bold text-white">Camera is turned off</p>
                  </div>
                )}

                {/* Floating Participant Label Badge */}
                <div className="absolute bottom-4 left-4 bg-slate-950/80 backdrop-blur-md px-3.5 py-1.5 rounded-xl border border-slate-800 flex items-center gap-2 z-10">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-pulse" />
                  <span className="text-xs font-bold text-white">{session.interviewerName} (Host)</span>
                </div>

                {/* Speaking Audio Wave Indicator */}
                <div className="absolute bottom-4 right-4 bg-slate-950/80 backdrop-blur-md p-2 rounded-xl border border-slate-800 z-10">
                  <Volume2 className="w-4 h-4 text-blue-400" />
                </div>
              </div>

              {/* Tile 2: Candidate Video Tile + Optional AI HUD Overlay */}
              <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden relative aspect-video shadow-2xl flex items-center justify-center group">
                {!isHost ? (
                  <video
                    ref={candidateVideoRef}
                    autoPlay
                    playsInline
                    muted={isMicMuted}
                    className={`w-full h-full object-cover ${isCamOff ? 'hidden' : 'block'}`}
                  />
                ) : remoteCandidateFrame ? (
                  <img
                    src={remoteCandidateFrame}
                    alt="Candidate Live Feed"
                    className="w-full h-full object-cover z-0"
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center text-center p-4 gap-3 text-slate-400">
                    <div className="w-16 h-16 rounded-full bg-emerald-600/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-extrabold text-xl">
                      {session.candidateName.charAt(0)}
                    </div>
                    <div>
                      <p className="text-xs font-bold text-white">{session.candidateName} (Candidate)</p>
                      <p className="text-[11px] text-emerald-400 animate-pulse">Candidate Video Feed Active</p>
                    </div>
                  </div>
                )}

                {!isHost && isCamOff && (
                  <div className="flex flex-col items-center justify-center text-center p-4 gap-3 text-slate-400">
                    <div className="w-16 h-16 rounded-full bg-slate-800 flex items-center justify-center text-slate-300 font-extrabold text-xl">
                      {session.candidateName.charAt(0)}
                    </div>
                    <p className="text-xs font-bold text-white">Camera is turned off</p>
                  </div>
                )}

                {showHudOverlay && (
                  <canvas
                    ref={overlayCanvasRef}
                    className="absolute inset-0 w-full h-full pointer-events-none z-10"
                  />
                )}

                {/* Floating Candidate Label & Emotion Badge */}
                <div className="absolute bottom-4 left-4 bg-slate-950/80 backdrop-blur-md px-3.5 py-1.5 rounded-xl border border-slate-800 flex items-center gap-2 z-10">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-xs font-bold text-white">{session.candidateName} (Candidate)</span>
                  <span className="bg-purple-600/80 text-[10px] text-white px-2 py-0.5 rounded-md font-bold">
                    {metrics.emotion}
                  </span>
                </div>

                {/* Eye Contact Stats Badge */}
                <div className="absolute top-4 right-4 bg-slate-950/80 backdrop-blur-md px-3 py-1 rounded-xl border border-slate-800 text-[10px] font-mono text-slate-300 z-10">
                  Eye Contact: <strong className="text-emerald-400">{metrics.eyeContactPercent}%</strong>
                </div>
              </div>
            </div>
          ) : (
            /* SCREEN PRESENTING MODE (Screen share dominates, 2 videos miniaturize) */
            <div className="flex-1 flex flex-col md:flex-row gap-4 items-stretch">
              <div className="flex-1 bg-black border border-slate-800 rounded-3xl overflow-hidden relative min-h-[400px]">
                <video
                  ref={screenShareVideoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-contain"
                />
                <div className="absolute top-4 left-4 bg-blue-600 text-white text-xs font-bold px-3 py-1 rounded-lg">
                  Presenting Desktop Screen
                </div>
              </div>

              {/* Mini PIP Video Tiles */}
              <div className="w-full md:w-64 space-y-3 flex flex-col justify-center">
                <div className="aspect-video bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden relative shadow-lg">
                  <video ref={interviewerVideoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
                  <span className="absolute bottom-2 left-2 text-[10px] font-bold text-white bg-slate-950/80 px-2 py-0.5 rounded">
                    Host: {session.interviewerName}
                  </span>
                </div>
                <div className="aspect-video bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden relative shadow-lg">
                  <video ref={candidateVideoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
                  <span className="absolute bottom-2 left-2 text-[10px] font-bold text-white bg-slate-950/80 px-2 py-0.5 rounded">
                    Candidate: {session.candidateName}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Subtitles / Speech-to-Text Banner Overlay */}
          {showCaptions && currentSpeechText && (
            <div className="bg-slate-900/90 backdrop-blur-md border border-slate-800 px-6 py-2.5 rounded-2xl max-w-2xl mx-auto text-center space-y-0.5 shadow-xl">
              <p className="text-xs text-slate-200 font-medium italic">"{currentSpeechText}"</p>
            </div>
          )}
        </div>

        {/* Right Drawer Panel (Participants / Chat / Proctoring) */}
        {activeDrawer !== 'none' && (
          <aside className="w-80 bg-slate-900 border-l border-slate-800 p-4 flex flex-col justify-between z-20">
            {/* Drawer Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                {activeDrawer === 'participants' && <Users className="w-4 h-4 text-blue-400" />}
                {activeDrawer === 'chat' && <MessageSquare className="w-4 h-4 text-blue-400" />}
                {activeDrawer === 'proctor' && <ShieldAlert className="w-4 h-4 text-red-400" />}
                {activeDrawer === 'participants' && 'In-Call Participants'}
                {activeDrawer === 'chat' && '2-Way Live Chat'}
                {activeDrawer === 'proctor' && 'AI Proctoring Monitor'}
              </h3>
              <button
                onClick={() => setActiveDrawer('none')}
                className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* DRAWER 1: Participants List & Waiting Queue */}
            {activeDrawer === 'participants' && (
              <div className="flex-1 overflow-y-auto py-3 space-y-4 text-xs">
                {/* Waiting Room Queue */}
                {isHost && waitingRequests.length > 0 && (
                  <div className="space-y-2">
                    <p className="text-[10px] font-bold uppercase text-amber-400 tracking-wider">
                      Waiting to Join ({waitingRequests.length})
                    </p>
                    {waitingRequests.map((req) => (
                      <div key={req.id} className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl flex items-center justify-between">
                        <span className="font-bold text-white">{req.name}</span>
                        <div className="flex gap-1.5">
                          <button
                            onClick={() => handleDeny(req.id)}
                            className="px-2 py-1 bg-slate-800 text-slate-300 text-[10px] font-bold rounded cursor-pointer"
                          >
                            Deny
                          </button>
                          <button
                            onClick={() => handleAdmit(req.id)}
                            className="px-2 py-1 bg-blue-600 text-white text-[10px] font-bold rounded cursor-pointer"
                          >
                            Admit
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                <div className="space-y-2">
                  <p className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">In Meeting (2)</p>
                  <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-blue-500" />
                      <span className="font-bold text-white">{session.interviewerName}</span>
                    </div>
                    <span className="text-[10px] text-blue-400 font-mono">HOST</span>
                  </div>
                  <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-500" />
                      <span className="font-bold text-white">{session.candidateName}</span>
                    </div>
                    <span className="text-[10px] text-emerald-400 font-mono">CANDIDATE</span>
                  </div>
                </div>
              </div>
            )}

            {/* DRAWER 2: 2-Way Chat */}
            {activeDrawer === 'chat' && (
              <div className="flex-1 flex flex-col justify-between py-3 overflow-hidden">
                <div className="flex-1 overflow-y-auto space-y-2.5 text-xs pr-1">
                  {chatMessages.map((msg) => (
                    <div key={msg.id} className="p-2.5 bg-slate-950 border border-slate-800 rounded-xl space-y-1">
                      <div className="flex justify-between text-[10px] text-slate-400">
                        <span className="font-bold text-blue-400">{msg.sender}</span>
                        <span>{msg.time}</span>
                      </div>
                      <p className="text-slate-200">{msg.text}</p>
                    </div>
                  ))}
                </div>

                <form onSubmit={handleSendChatMessage} className="flex gap-2 pt-3 border-t border-slate-800">
                  <input
                    type="text"
                    value={inputChatText}
                    onChange={(e) => setInputChatText(e.target.value)}
                    placeholder="Type in-meeting message..."
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                  />
                  <button
                    type="submit"
                    className="bg-blue-600 hover:bg-blue-500 text-white p-2 rounded-xl text-xs font-bold cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              </div>
            )}

            {/* DRAWER 3: AI Proctoring Monitor (Discreet Host Panel) */}
            {activeDrawer === 'proctor' && (
              <div className="flex-1 overflow-y-auto py-3 space-y-4 text-xs">
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Fraud Score:</span>
                    <span className={`font-extrabold ${session.fraudScore >= 40 ? 'text-red-400' : 'text-emerald-400'}`}>
                      {session.fraudScore} / 100 ({session.riskLevel})
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Eye Contact:</span>
                    <span className="font-bold text-white">{metrics.eyeContactPercent}%</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Face Count:</span>
                    <span className="font-bold text-white">{metrics.faceCount}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Gaze Direction:</span>
                    <span className="font-bold text-blue-400">{metrics.gazeDirection}</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">Proctoring Flag Timeline</p>
                  {session.violations.length === 0 ? (
                    <p className="text-[11px] text-slate-500 italic">No suspicious flags detected so far.</p>
                  ) : (
                    session.violations.map((v) => (
                      <div key={v.id} className="p-2.5 bg-red-500/10 border border-red-500/30 rounded-xl space-y-1">
                        <div className="flex justify-between text-[10px]">
                          <span className="font-bold text-red-400">{v.title}</span>
                          <span className="text-slate-400">{v.timestamp}</span>
                        </div>
                        <p className="text-[11px] text-slate-300">{v.description}</p>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </aside>
        )}
      </div>

      {/* Bottom Control Bar (Google Meet Style Toolbar) */}
      <footer className="bg-slate-900 border-t border-slate-800 px-6 py-3 flex items-center justify-between z-30">
        {/* Left: Meeting Code Badge */}
        <div className="flex items-center gap-3">
          <span className="text-xs font-mono font-bold text-slate-300 hidden md:inline">
            {session.sessionId}
          </span>
          {recordedVideoUrl && (
            <button
              onClick={() => {
                const a = document.createElement('a');
                a.href = recordedVideoUrl;
                a.download = `Interview_Recording_${session.sessionId}.webm`;
                a.click();
              }}
              className="text-xs text-blue-400 hover:underline font-bold flex items-center gap-1"
            >
              <Download className="w-3.5 h-3.5" /> Download Recording
            </button>
          )}
        </div>

        {/* Center: Main Media Action Controls */}
        <div className="flex items-center gap-3">
          <button
            onClick={toggleMicrophone}
            className={`p-3 rounded-full transition cursor-pointer ${
              isMicMuted ? 'bg-red-600 text-white' : 'bg-slate-800 hover:bg-slate-700 text-white'
            }`}
            title={isMicMuted ? 'Unmute microphone' : 'Mute microphone'}
          >
            {isMicMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          <button
            onClick={toggleCamera}
            className={`p-3 rounded-full transition cursor-pointer ${
              isCamOff ? 'bg-red-600 text-white' : 'bg-slate-800 hover:bg-slate-700 text-white'
            }`}
            title={isCamOff ? 'Turn on camera' : 'Turn off camera'}
          >
            {isCamOff ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
          </button>

          <button
            onClick={toggleScreenShare}
            className={`p-3 rounded-full transition cursor-pointer ${
              isPresentingScreen ? 'bg-blue-600 text-white' : 'bg-slate-800 hover:bg-slate-700 text-white'
            }`}
            title="Present desktop screen"
          >
            <Monitor className="w-5 h-5" />
          </button>

          <button
            onClick={() => setShowCaptions(!showCaptions)}
            className={`p-3 rounded-full transition cursor-pointer ${
              showCaptions ? 'bg-blue-600 text-white' : 'bg-slate-800 hover:bg-slate-700 text-white'
            }`}
            title="Toggle Live Subtitles CC"
          >
            <Subtitles className="w-5 h-5" />
          </button>

          <button
            onClick={() => setShowHudOverlay(!showHudOverlay)}
            className={`p-3 rounded-full transition cursor-pointer ${
              showHudOverlay ? 'bg-purple-600 text-white' : 'bg-slate-800 hover:bg-slate-700 text-white'
            }`}
            title="Toggle Vision Mesh HUD"
          >
            <Eye className="w-5 h-5" />
          </button>

          {/* End Call Button */}
          <button
            onClick={handleFinishInterview}
            className="p-3 bg-red-600 hover:bg-red-500 text-white rounded-full transition shadow-lg shadow-red-600/30 cursor-pointer"
            title="Leave / End Call"
          >
            <PhoneOff className="w-5 h-5" />
          </button>
        </div>

        {/* Right: Drawer Toggles */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveDrawer(activeDrawer === 'participants' ? 'none' : 'participants')}
            className={`p-2.5 rounded-xl border text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
              activeDrawer === 'participants' ? 'bg-blue-600 border-blue-500 text-white' : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Users className="w-4 h-4" />
            <span className="hidden sm:inline">People</span>
          </button>

          <button
            onClick={() => setActiveDrawer(activeDrawer === 'chat' ? 'none' : 'chat')}
            className={`p-2.5 rounded-xl border text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
              activeDrawer === 'chat' ? 'bg-blue-600 border-blue-500 text-white' : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span className="hidden sm:inline">Chat</span>
          </button>

          {isHost && (
            <button
              onClick={() => setActiveDrawer(activeDrawer === 'proctor' ? 'none' : 'proctor')}
              className={`p-2.5 rounded-xl border text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                activeDrawer === 'proctor' ? 'bg-red-600 border-red-500 text-white' : 'bg-slate-950 border-slate-800 text-red-400 hover:bg-slate-800'
              }`}
            >
              <ShieldAlert className="w-4 h-4" />
              <span className="hidden sm:inline">Proctor</span>
            </button>
          )}
        </div>
      </footer>
    </div>
  );
};
