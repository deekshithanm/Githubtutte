import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { socketClient } from '../../lib/socket';
import { visionEngine, VisionMetrics } from '../../lib/visionEngine';
import { InterviewSession, FraudViolation, TranscriptSegment } from '../../types';
import { ShieldAlert, Video, Mic, MicOff, Monitor, PhoneOff, AlertTriangle, Clock, Volume2, ShieldCheck, Sparkles, Send, CheckCircle2, Eye, VideoOff, Disc, Download, Pause, Play, MessageSquare } from 'lucide-react';
import { getWebcamAndMicStream, getDisplayScreenStream } from '../../lib/mediaUtils';

interface InterviewRoomProps {
  session: InterviewSession;
  mediaStreams?: { camStream: MediaStream; screenStream: MediaStream };
  onEndInterview: (session: InterviewSession) => void;
}

export const InterviewRoom: React.FC<InterviewRoomProps> = ({ session: initialSession, mediaStreams, onEndInterview }) => {
  const { user } = useAuth();
  const [session, setSession] = useState<InterviewSession>(initialSession);

  // Video & Canvas Element Refs
  const candidateVideoRef = useRef<HTMLVideoElement>(null);
  const overlayCanvasRef = useRef<HTMLCanvasElement>(null);
  const candidateScreenVideoRef = useRef<HTMLVideoElement>(null);
  const interviewerVideoRef = useRef<HTMLVideoElement>(null);

  // Local Media Controls State
  const [isMicMuted, setIsMicMuted] = useState(false);
  const [isCamOff, setIsCamOff] = useState(false);
  const [showHudOverlay, setShowHudOverlay] = useState(true);

  // Remote Face-to-Face Live Communication Frames (from WebSocket)
  const [remoteCandidateFrame, setRemoteCandidateFrame] = useState<string | null>(null);
  const [remoteInterviewerFrame, setRemoteInterviewerFrame] = useState<string | null>(null);

  // Video Recording State ("Video taken the interview")
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [recordedVideoUrl, setRecordedVideoUrl] = useState<string | null>(session.recordedVideoUrl || null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);

  // Store active MediaStream references
  const candidateCamStreamRef = useRef<MediaStream | null>(null);
  const interviewerCamStreamRef = useRef<MediaStream | null>(null);

  // Real-Time Computer Vision & Proctoring Metrics
  const [metrics, setMetrics] = useState<VisionMetrics>({
    faceDetected: true,
    faceCount: 1,
    faceVisibilityPercent: 100,
    emotion: 'Neutral',
    emotionConfidence: 0.92,
    emotionsBreakdown: { neutral: 80, happy: 10, angry: 0, sad: 0, fear: 0, surprise: 5, disgust: 0, confused: 0, stressed: 0, nervous: 5 },
    eyeContactPercent: 96,
    gazeDirection: 'CENTER',
    headPose: { yaw: 0, pitch: 0, roll: 0, direction: 'FORWARD' },
    detectedObjects: [],
    audioLevelDb: 24,
    voiceActive: true,
    multipleVoicesDetected: false,
  });

  // Active Warning Toasts & Violations
  const [latestViolation, setLatestViolation] = useState<FraudViolation | null>(null);
  const [warningToast, setWarningToast] = useState<string | null>(null);

  // Timer
  const [elapsedSeconds, setElapsedSeconds] = useState(0);

  // Speech Recognition & Subtitles
  const [isListening, setIsListening] = useState(false);
  const [currentSpeechText, setCurrentSpeechText] = useState('');
  const [currentTranslation, setCurrentTranslation] = useState('');
  const [transcript, setTranscript] = useState<TranscriptSegment[]>(session.transcript || []);

  // Live Chat State
  const [activeTab, setActiveTab] = useState<'questions' | 'transcript' | 'chat'>('questions');
  const [chatMessages, setChatMessages] = useState<Array<{ id: string; sender: string; text: string; time: string }>>([
    { id: '1', sender: 'System Guardian', text: 'AI Secured Interview Room connected. Real-time proctoring is active.', time: new Date().toLocaleTimeString() }
  ]);
  const [inputChatText, setInputChatText] = useState('');

  // Start Video Recording of Interview
  const startInterviewRecording = (stream: MediaStream) => {
    try {
      recordedChunksRef.current = [];
      const recorder = new MediaRecorder(stream, { mimeType: 'video/webm;codecs=vp8,opus' });
      
      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          recordedChunksRef.current.push(e.data);
        }
      };

      recorder.onstop = () => {
        const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
        const url = URL.createObjectURL(blob);
        setRecordedVideoUrl(url);
      };

      recorder.start(1000);
      mediaRecorderRef.current = recorder;
      setIsRecording(true);
    } catch (err) {
      console.warn('Fallback recorder initialized:', err);
      // Fallback: simulate taken video URL
      setIsRecording(true);
    }
  };

  const stopInterviewRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    setIsRecording(false);
  };

  // Synchronize All Video & Audio Streams
  useEffect(() => {
    socketClient.connect();
    socketClient.subscribe(session.id, user?.role || 'candidate');

    // Sync active session data
    fetch(`/api/interviews/${session.id}`, { method: 'GET' })
      .then((res) => res.json())
      .then((data) => {
        if (data && data.id) setSession(data);
      })
      .catch((err) => console.error(err));

    let isMounted = true;

    async function initRoomStreams() {
      // 1. Candidate Camera Stream Setup
      let candCamStream = mediaStreams?.camStream || null;
      if (!candCamStream) {
        candCamStream = await getWebcamAndMicStream();
      }
      candidateCamStreamRef.current = candCamStream;

      if (isMounted && candidateVideoRef.current && candCamStream) {
        candidateVideoRef.current.srcObject = candCamStream;
        candidateVideoRef.current.play().catch(() => {});
      }

      // 2. Candidate Screen Share Stream Setup
      let candScreenStream = mediaStreams?.screenStream || null;
      if (!candScreenStream) {
        candScreenStream = await getDisplayScreenStream();
      }

      if (isMounted && candidateScreenVideoRef.current && candScreenStream) {
        candidateScreenVideoRef.current.srcObject = candScreenStream;
        candidateScreenVideoRef.current.play().catch(() => {});
      }

      // 3. Interviewer Camera Stream Setup (Enables Face-To-Face Live Communication)
      const intCamStream = await getWebcamAndMicStream();
      interviewerCamStreamRef.current = intCamStream;

      if (isMounted && interviewerVideoRef.current && intCamStream) {
        interviewerVideoRef.current.srcObject = intCamStream;
        interviewerVideoRef.current.play().catch(() => {});
      }

      // 4. Start Video Recording of Candidate Session
      if (candCamStream) {
        startInterviewRecording(candCamStream);
      }

      // 5. Start Computer Vision AI Engine on Candidate Video Stream
      if (isMounted && candidateVideoRef.current && overlayCanvasRef.current) {
        visionEngine.start(
          candidateVideoRef.current,
          overlayCanvasRef.current,
          candCamStream,
          (violation) => handleViolationLogged(violation),
          (updatedMetrics) => setMetrics(updatedMetrics)
        );
      }
    }

    initRoomStreams();

    // Broadcast live video frame over WebSockets for 2-Way Face-To-Face Communication
    const frameBroadcastInterval = setInterval(() => {
      try {
        const activeVideo = user?.role === 'interviewer' ? interviewerVideoRef.current : candidateVideoRef.current;
        if (activeVideo && activeVideo.videoWidth > 0) {
          const canvas = document.createElement('canvas');
          canvas.width = 320;
          canvas.height = 240;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(activeVideo, 0, 0, canvas.width, canvas.height);
            const dataUrl = canvas.toDataURL('image/jpeg', 0.5);
            socketClient.sendVideoFrame(session.id, user?.role || 'candidate', dataUrl);
          }
        }
      } catch (e) {
        // Ignore frame capture issues
      }
    }, 400);

    // WebSocket event listener
    const unsubscribeSocket = socketClient.addListener((data) => {
      if (data.type === 'fraud_update' && data.interviewId === session.id) {
        setSession((prev) => ({
          ...prev,
          fraudScore: data.fraudScore,
          riskLevel: data.riskLevel,
          violations: [data.violation, ...prev.violations],
        }));
        setLatestViolation(data.violation);
        setWarningToast(`PROCTORING WARNING: ${data.violation.title}`);
        setTimeout(() => setWarningToast(null), 5000);
      } else if (data.type === 'transcript_updated' && data.interviewId === session.id) {
        setTranscript((prev) => [...prev, data.segment]);
      } else if (data.type === 'video_frame' && data.interviewId === session.id) {
        if (data.role === 'interviewer') {
          setRemoteInterviewerFrame(data.frameDataUrl);
        } else if (data.role === 'candidate') {
          setRemoteCandidateFrame(data.frameDataUrl);
        }
      } else if (data.type === 'chat_message' && data.interviewId === session.id) {
        setChatMessages((prev) => [...prev, data.message]);
      } else if (data.type === 'media_state' && data.interviewId === session.id) {
        if (data.mediaState?.role === 'candidate') {
          setSession((prev) => ({
            ...prev,
            cameraStatus: data.mediaState.cameraOn,
            micStatus: data.mediaState.micOn,
          }));
        }
      }
    });

    // Session Timer
    const timerInterval = setInterval(() => {
      setElapsedSeconds((prev) => prev + 1);
      setRecordingSeconds((prev) => prev + 1);
    }, 1000);

    return () => {
      isMounted = false;
      visionEngine.stop();
      clearInterval(frameBroadcastInterval);
      unsubscribeSocket();
      clearInterval(timerInterval);
    };
  }, [session.id]);

  const handleViolationLogged = (violation: FraudViolation) => {
    socketClient.sendViolation(session.id, violation);
  };

  // Toggle Microphone
  const toggleMicrophone = () => {
    const newMuteState = !isMicMuted;
    setIsMicMuted(newMuteState);

    const activeStream = user?.role === 'interviewer' ? interviewerCamStreamRef.current : candidateCamStreamRef.current;
    if (activeStream) {
      activeStream.getAudioTracks().forEach((track) => {
        track.enabled = !newMuteState;
      });
    }

    socketClient.sendMediaState(session.id, {
      role: user?.role || 'candidate',
      cameraOn: !isCamOff,
      micOn: !newMuteState,
    });
  };

  // Toggle Camera
  const toggleCamera = () => {
    const newCamState = !isCamOff;
    setIsCamOff(newCamState);

    const activeStream = user?.role === 'interviewer' ? interviewerCamStreamRef.current : candidateCamStreamRef.current;
    if (activeStream) {
      activeStream.getVideoTracks().forEach((track) => {
        track.enabled = !newCamState;
      });
    }

    socketClient.sendMediaState(session.id, {
      role: user?.role || 'candidate',
      cameraOn: !newCamState,
      micOn: !isMicMuted,
    });
  };

  // Send Chat Message
  const handleSendChatMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputChatText.trim()) return;

    const msg = {
      id: 'msg_' + Date.now(),
      sender: user?.name || (user?.role === 'interviewer' ? 'Interviewer' : 'Candidate'),
      text: inputChatText.trim(),
      time: new Date().toLocaleTimeString(),
    };

    setChatMessages((prev) => [...prev, msg]);
    setInputChatText('');
  };

  // Speech-To-Text Handler using Web Speech API with Gemini translation fallback
  useEffect(() => {
    if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) return;

    try {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onresult = async (event: any) => {
        const result = event.results[event.results.length - 1];
        const text = result[0].transcript;
        setCurrentSpeechText(text);

        if (result.isFinal && text.trim().length > 3) {
          const res = await fetch('/api/gemini/translate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text, targetLang: 'English' }),
          });
          const data = await res.json();
          const translated = data.translatedText || text;

          setCurrentTranslation(translated);

          const segment: TranscriptSegment = {
            id: 'tr_' + Date.now(),
            speaker: user?.role === 'interviewer' ? 'Interviewer' : 'Candidate',
            timestamp: new Date().toLocaleTimeString(),
            originalText: text,
            translatedText: translated,
            language: 'en',
          };

          socketClient.sendTranscriptAppend(session.id, segment);
          setCurrentSpeechText('');
        }
      };

      recognition.start();
      setIsListening(true);

      return () => {
        recognition.stop();
      };
    } catch (e) {
      console.log('Speech recognition fallback active');
    }
  }, []);

  const handleFinishInterview = async () => {
    stopInterviewRecording();

    try {
      const res = await fetch(`/api/interviews/${session.id}/end`, {
        method: 'POST',
      });
      const data = await res.json();
      onEndInterview({
        ...data.session,
        recordedVideoUrl: recordedVideoUrl || 'demo_recording.mp4',
      });
    } catch (err) {
      console.error('Failed to end interview', err);
      onEndInterview({
        ...session,
        status: 'COMPLETED',
        recordedVideoUrl: recordedVideoUrl || 'demo_recording.mp4',
      });
    }
  };

  const downloadTakenVideo = () => {
    if (recordedVideoUrl) {
      const a = document.createElement('a');
      a.href = recordedVideoUrl;
      a.download = `Interview_Recording_${session.sessionId}.webm`;
      a.click();
    } else {
      alert('Video recording is generating. Please wait a moment.');
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col relative overflow-hidden font-sans">
      {/* Top Proctoring HUD Status Bar */}
      <header className="bg-slate-900/90 backdrop-blur-md border-b border-slate-800 px-6 py-3 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
            <span className="text-xs font-bold text-white tracking-wide uppercase">
              {session.sessionId}
            </span>
          </div>

          <div className="h-4 w-px bg-slate-800" />

          <div className="flex items-center gap-2 text-xs font-mono text-slate-300">
            <Clock className="w-3.5 h-3.5 text-blue-400" />
            <span>{formatTime(elapsedSeconds)}</span>
          </div>

          {/* Video Recording Status Badge */}
          <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/30 px-3 py-1 rounded-full text-xs font-mono text-red-400 font-bold">
            <Disc className={`w-3.5 h-3.5 ${isRecording ? 'animate-spin text-red-500' : ''}`} />
            <span>{isRecording ? `REC ${formatTime(recordingSeconds)}` : 'REC PAUSED'}</span>
          </div>
        </div>

        {/* Live Circular Fraud Gauge & Risk Badge */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3 bg-slate-950 px-3.5 py-1.5 rounded-xl border border-slate-800">
            <div className="relative w-7 h-7 flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                <path
                  className="text-slate-800"
                  strokeWidth="3.5"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
                <path
                  className={
                    session.fraudScore >= 50
                      ? 'text-red-500'
                      : session.fraudScore >= 25
                      ? 'text-amber-500'
                      : 'text-emerald-500'
                  }
                  strokeDasharray={`${session.fraudScore}, 100`}
                  strokeWidth="3.5"
                  strokeLinecap="round"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
              </svg>
              <span className="absolute text-[9px] font-bold text-white">
                {session.fraudScore}
              </span>
            </div>

            <div>
              <p className="text-[9px] font-bold uppercase tracking-wider text-slate-400">
                Fraud Risk
              </p>
              <p
                className={`text-xs font-extrabold uppercase ${
                  session.riskLevel === 'HIGH'
                    ? 'text-red-400'
                    : session.riskLevel === 'MEDIUM'
                    ? 'text-amber-400'
                    : 'text-emerald-400'
                }`}
              >
                {session.riskLevel} RISK
              </p>
            </div>
          </div>

          <button
            onClick={handleFinishInterview}
            className="bg-red-600 hover:bg-red-500 text-white text-xs font-bold py-2 px-4 rounded-xl transition flex items-center gap-1.5 shadow-lg shadow-red-600/20 cursor-pointer"
          >
            <PhoneOff className="w-4 h-4" />
            End Interview
          </button>
        </div>
      </header>

      {/* Warning Toast Banner */}
      {warningToast && (
        <div className="bg-red-600 text-white px-6 py-2 text-xs font-bold flex items-center justify-between shadow-xl z-50 animate-bounce">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>{warningToast}</span>
          </div>
          <span className="text-[10px] bg-black/20 px-2 py-0.5 rounded font-mono">
            FLAGGED TO ADMIN
          </span>
        </div>
      )}

      {/* Main Workspace Grid */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-4 p-4 overflow-hidden">
        {/* Left Column (2 Cols): Face-to-Face Video Streams Grid & Screen Share */}
        <div className="lg:col-span-2 flex flex-col space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 flex-1">
            {/* 1. Candidate Video Stream + Vision Canvas HUD */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden relative aspect-video flex items-center justify-center group shadow-xl">
              <video
                ref={candidateVideoRef}
                autoPlay
                playsInline
                muted={user?.role === 'candidate' && isMicMuted}
                className={`w-full h-full object-cover ${isCamOff && user?.role === 'candidate' ? 'hidden' : ''}`}
              />

              {/* Render remote candidate frame snapshot if viewer is Interviewer */}
              {user?.role !== 'candidate' && remoteCandidateFrame && (
                <img
                  src={remoteCandidateFrame}
                  alt="Candidate Live Feed"
                  className="absolute inset-0 w-full h-full object-cover z-0"
                />
              )}
              
              {showHudOverlay && (
                <canvas
                  ref={overlayCanvasRef}
                  className="absolute inset-0 w-full h-full pointer-events-none z-10"
                />
              )}

              {/* Status Badges Overlay */}
              <div className="absolute top-3 left-3 flex items-center gap-2 z-20">
                <span className="bg-slate-950/80 backdrop-blur-md text-white text-[10px] font-bold px-2.5 py-1 rounded-lg border border-slate-800 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  {session.candidateName} (Candidate)
                </span>
                <span className="bg-purple-600/90 text-white text-[10px] font-bold px-2 py-1 rounded-lg">
                  {metrics.emotion}
                </span>
              </div>

              <div className="absolute bottom-3 left-3 right-3 flex justify-between items-center text-[10px] text-slate-300 bg-slate-950/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-800 z-20">
                <span>Eye Contact: {metrics.eyeContactPercent}%</span>
                <span>Gaze: {metrics.gazeDirection}</span>
                <span>Head Yaw: {metrics.headPose.yaw}°</span>
              </div>
            </div>

            {/* 2. Interviewer Video Stream (Live Face-to-Face Feed) */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden relative aspect-video flex items-center justify-center shadow-xl">
              <video
                ref={interviewerVideoRef}
                autoPlay
                playsInline
                muted={user?.role === 'interviewer' && isMicMuted}
                className="w-full h-full object-cover"
              />

              {/* Render remote interviewer frame snapshot if viewer is Candidate */}
              {user?.role === 'candidate' && remoteInterviewerFrame && (
                <img
                  src={remoteInterviewerFrame}
                  alt="Interviewer Live Feed"
                  className="absolute inset-0 w-full h-full object-cover z-0"
                />
              )}

              <div className="absolute top-3 left-3 z-20">
                <span className="bg-slate-950/80 backdrop-blur-md text-white text-[10px] font-bold px-2.5 py-1 rounded-lg border border-slate-800 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
                  {session.interviewerName} (Interviewer Live)
                </span>
              </div>

              {/* Live Audio Meter & Speaking Feedback */}
              <div className="absolute bottom-3 left-3 right-3 flex justify-between items-center text-[10px] text-slate-300 bg-slate-950/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-800 z-20">
                <span className="flex items-center gap-1.5">
                  <Volume2 className="w-3.5 h-3.5 text-blue-400" /> Audio Level: {metrics.audioLevelDb}%
                </span>
                <span className="text-emerald-400 font-bold">2-Way Face-To-Face Active</span>
              </div>
            </div>
          </div>

          {/* Interactive In-Room Media Controls Toolbar */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <button
                onClick={toggleMicrophone}
                className={`p-2.5 rounded-xl border text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
                  isMicMuted
                    ? 'bg-red-500/10 border-red-500/30 text-red-400'
                    : 'bg-slate-950 border-slate-800 text-slate-200 hover:bg-slate-800'
                }`}
              >
                {isMicMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4 text-emerald-400" />}
                <span>{isMicMuted ? 'Muted' : 'Mic Active'}</span>
              </button>

              <button
                onClick={toggleCamera}
                className={`p-2.5 rounded-xl border text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
                  isCamOff
                    ? 'bg-red-500/10 border-red-500/30 text-red-400'
                    : 'bg-slate-950 border-slate-800 text-slate-200 hover:bg-slate-800'
                }`}
              >
                {isCamOff ? <VideoOff className="w-4 h-4" /> : <Video className="w-4 h-4 text-blue-400" />}
                <span>{isCamOff ? 'Cam Off' : 'Cam Active'}</span>
              </button>

              <button
                onClick={() => setShowHudOverlay(!showHudOverlay)}
                className={`p-2.5 rounded-xl border text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
                  showHudOverlay
                    ? 'bg-purple-500/10 border-purple-500/30 text-purple-300'
                    : 'bg-slate-950 border-slate-800 text-slate-400'
                }`}
              >
                <Eye className="w-4 h-4" />
                <span>AI HUD Mesh</span>
              </button>

              {/* Video Taken / Video Recording Control Button */}
              <button
                onClick={isRecording ? stopInterviewRecording : () => candidateCamStreamRef.current && startInterviewRecording(candidateCamStreamRef.current)}
                className={`p-2.5 rounded-xl border text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
                  isRecording
                    ? 'bg-red-500/10 border-red-500/30 text-red-400'
                    : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                }`}
              >
                <Disc className={`w-4 h-4 ${isRecording ? 'animate-spin' : ''}`} />
                <span>{isRecording ? 'Stop Video Rec' : 'Take Session Video'}</span>
              </button>

              {recordedVideoUrl && (
                <button
                  onClick={downloadTakenVideo}
                  className="p-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-md shadow-blue-600/20 cursor-pointer"
                  title="Download taken video of the interview"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Video</span>
                </button>
              )}
            </div>

            <span className="text-xs font-mono text-slate-400 hidden sm:inline">
              Secured Stream: <strong className="text-emerald-400">ENCRYPTED_RTC_LIVE</strong>
            </span>
          </div>

          {/* Candidate Mandatory Screen Sharing Window */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="font-bold text-white flex items-center gap-1.5">
                <Monitor className="w-4 h-4 text-blue-400" />
                Live Candidate Screen Share Feed
              </span>
              <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/20 font-mono">
                SCREEN LOCKDOWN ACTIVE
              </span>
            </div>

            <div className="aspect-[21/9] bg-black rounded-xl overflow-hidden border border-slate-800/80 flex items-center justify-center">
              <video
                ref={candidateScreenVideoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-contain"
              />
            </div>
          </div>
        </div>

        {/* Right Column (1 Col): Questions, Speech Transcripts & Live Face-to-Face Chat */}
        <div className="flex flex-col space-y-4">
          {/* Section Tabs */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-1.5 flex gap-1">
            <button
              onClick={() => setActiveTab('questions')}
              className={`flex-1 py-2 text-xs font-bold rounded-xl transition ${
                activeTab === 'questions' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              Questions
            </button>
            <button
              onClick={() => setActiveTab('transcript')}
              className={`flex-1 py-2 text-xs font-bold rounded-xl transition ${
                activeTab === 'transcript' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              Subtitles & AI
            </button>
            <button
              onClick={() => setActiveTab('chat')}
              className={`flex-1 py-2 text-xs font-bold rounded-xl transition ${
                activeTab === 'chat' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              2-Way Chat
            </button>
          </div>

          {/* TAB 1: Questions */}
          {activeTab === 'questions' && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 flex-1 flex flex-col justify-between">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-blue-400 uppercase tracking-wider">
                    Question {session.currentQuestionIndex + 1} of {session.questions.length}
                  </span>
                  <span className="text-xs text-slate-400 font-mono">
                    Category: {session.questions[session.currentQuestionIndex]?.category || 'General'}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-white leading-relaxed">
                  {session.questions[session.currentQuestionIndex]?.text}
                </h3>
              </div>

              <div className="flex items-center justify-between text-xs text-slate-400 pt-3 border-t border-slate-800">
                <span>Time Limit: {session.questions[session.currentQuestionIndex]?.timeLimitSeconds || 300}s</span>
                <button
                  onClick={() => {
                    if (session.currentQuestionIndex < session.questions.length - 1) {
                      setSession({ ...session, currentQuestionIndex: session.currentQuestionIndex + 1 });
                    }
                  }}
                  className="text-xs text-blue-400 hover:underline font-medium cursor-pointer"
                >
                  Next Question →
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: Subtitles & AI */}
          {activeTab === 'transcript' && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex-1 flex flex-col space-y-3 overflow-hidden">
              <h4 className="text-xs font-bold text-white flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Volume2 className="w-4 h-4 text-blue-400" />
                  Live Speech Subtitles & Translation
                </span>
                {isListening && (
                  <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1">
                    <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                    Transcribing
                  </span>
                )}
              </h4>

              {currentSpeechText && (
                <div className="p-3 bg-blue-600/10 border border-blue-500/20 rounded-xl text-xs space-y-1">
                  <p className="text-slate-300 italic">"{currentSpeechText}"</p>
                  {currentTranslation && (
                    <p className="text-blue-300 font-medium">Auto-Translated: "{currentTranslation}"</p>
                  )}
                </div>
              )}

              <div className="flex-1 bg-slate-950 rounded-xl border border-slate-800 p-3 overflow-y-auto space-y-2 text-xs">
                {transcript.map((t) => (
                  <div key={t.id} className="space-y-0.5">
                    <span className="font-bold text-blue-400">{t.speaker} ({t.timestamp}):</span>
                    <p className="text-slate-200">{t.originalText}</p>
                    {t.translatedText !== t.originalText && (
                      <p className="text-slate-400 italic text-[11px]">En: {t.translatedText}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: 2-Way Chat */}
          {activeTab === 'chat' && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex-1 flex flex-col justify-between space-y-3 overflow-hidden">
              <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                <MessageSquare className="w-4 h-4 text-blue-400" />
                Live 2-Way In-Room Chat
              </h4>

              <div className="flex-1 bg-slate-950 rounded-xl border border-slate-800 p-3 overflow-y-auto space-y-2 text-xs">
                {chatMessages.map((msg) => (
                  <div key={msg.id} className="p-2 bg-slate-900 rounded-lg border border-slate-800 space-y-0.5">
                    <div className="flex justify-between items-center text-[10px] text-slate-400">
                      <span className="font-bold text-blue-400">{msg.sender}</span>
                      <span>{msg.time}</span>
                    </div>
                    <p className="text-slate-200">{msg.text}</p>
                  </div>
                ))}
              </div>

              <form onSubmit={handleSendChatMessage} className="flex gap-2">
                <input
                  type="text"
                  value={inputChatText}
                  onChange={(e) => setInputChatText(e.target.value)}
                  placeholder="Type message to candidate or interviewer..."
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                />
                <button
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-500 text-white px-3 py-2 rounded-xl text-xs font-bold flex items-center justify-center cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>
          )}

          {/* Anti-Cheating Simulator Controls */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-2">
            <p className="text-[10px] font-bold uppercase text-slate-400 tracking-wider flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              Proctoring Simulator (Test Anti-Cheating Flags)
            </p>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => visionEngine.triggerObjectDetectionScan()}
                className="bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 py-1.5 px-2 rounded-xl text-[10px] font-medium cursor-pointer"
              >
                + Mobile Phone Detected
              </button>
              <button
                onClick={() => visionEngine.triggerMultipleFaceScan()}
                className="bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 py-1.5 px-2 rounded-xl text-[10px] font-medium cursor-pointer"
              >
                + Multiple Faces Detected
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
