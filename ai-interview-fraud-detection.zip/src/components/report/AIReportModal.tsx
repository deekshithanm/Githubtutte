import React, { useRef } from 'react';
import { InterviewSession } from '../../types';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { ShieldCheck, FileText, Download, AlertTriangle, CheckCircle2, User, Clock, Calendar, X, Sparkles, Camera } from 'lucide-react';

interface AIReportModalProps {
  session: InterviewSession;
  onClose: () => void;
}

export const AIReportModal: React.FC<AIReportModalProps> = ({ session, onClose }) => {
  const reportRef = useRef<HTMLDivElement>(null);
  const report = session.aiReport;

  const handleDownloadPDF = async () => {
    if (!reportRef.current) return;

    try {
      const canvas = await html2canvas(reportRef.current, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#020617', // Dark theme background matching
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save(`AI_Interview_Report_${session.candidateName.replace(/\s+/g, '_')}.pdf`);
    } catch (err) {
      console.error('PDF generation error', err);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="p-6 bg-slate-900 border-b border-slate-800 flex items-center justify-between sticky top-0 z-20">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-600/10 border border-blue-500/20 rounded-xl text-blue-400">
              <FileText className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">AI Interview Evaluation Report</h2>
              <p className="text-xs text-slate-400">Session ID: {session.sessionId}</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleDownloadPDF}
              className="bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold py-2 px-4 rounded-xl transition flex items-center gap-2 shadow-lg shadow-blue-600/20"
            >
              <Download className="w-4 h-4" />
              Download PDF Report
            </button>

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white bg-slate-950 border border-slate-800 rounded-xl"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Modal Printable Content Area */}
        <div className="flex-1 p-8 overflow-y-auto space-y-8 bg-slate-950 text-slate-100" ref={reportRef}>
          {/* Executive Summary Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div className="space-y-2">
              <span className="text-[10px] font-mono font-bold text-blue-400 uppercase tracking-widest bg-blue-500/10 px-2.5 py-1 rounded-md border border-blue-500/20">
                OFFICIAL PROCTORING CERTIFICATE
              </span>
              <h1 className="text-2xl font-extrabold text-white">{session.candidateName}</h1>
              <p className="text-xs text-slate-400">
                Position: <strong>{session.jobRole}</strong> • Interviewer: {session.interviewerName}
              </p>
            </div>

            <div className="flex items-center gap-4 bg-slate-950 p-4 rounded-2xl border border-slate-800">
              <div className="text-center pr-4 border-r border-slate-800">
                <p className="text-[10px] text-slate-400 uppercase font-bold">Fraud Score</p>
                <p className="text-2xl font-black text-white mt-0.5">{session.fraudScore}/100</p>
              </div>

              <div>
                <p className="text-[10px] text-slate-400 uppercase font-bold">Risk Level</p>
                <span
                  className={`inline-block mt-1 px-3 py-1 rounded-full text-xs font-extrabold uppercase border ${
                    session.riskLevel === 'HIGH'
                      ? 'bg-red-500/10 text-red-400 border-red-500/30'
                      : session.riskLevel === 'MEDIUM'
                      ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                      : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                  }`}
                >
                  {session.riskLevel} RISK
                </span>
              </div>
            </div>
          </div>

          {/* Scores Breakdown Grid */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
              <p className="text-xs text-slate-400 font-medium">Face Visibility</p>
              <p className="text-2xl font-bold text-white mt-1">{session.faceVisibilityPercent}%</p>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
              <p className="text-xs text-slate-400 font-medium">Eye Contact Rate</p>
              <p className="text-2xl font-bold text-white mt-1">{session.eyeGaze?.eyeContactPercentage || 94}%</p>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
              <p className="text-xs text-slate-400 font-medium">Technical Competency</p>
              <p className="text-2xl font-bold text-white mt-1">{report?.technicalCompetencyScore || 88}/100</p>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
              <p className="text-xs text-slate-400 font-medium">Soft Skills & Integrity</p>
              <p className="text-2xl font-bold text-white mt-1">{report?.softSkillsScore || 82}/100</p>
            </div>
          </div>

          {/* Emotion Timeline Breakdown */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <h3 className="text-sm font-bold text-white">Facial Expression & Emotion Timeline Breakdown</h3>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3 text-xs">
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-center">
                <p className="text-slate-400 text-[10px]">Neutral</p>
                <p className="text-base font-bold text-white mt-0.5">{session.emotions?.neutral || 70}%</p>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-center">
                <p className="text-slate-400 text-[10px]">Happy</p>
                <p className="text-base font-bold text-white mt-0.5">{session.emotions?.happy || 15}%</p>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-center">
                <p className="text-slate-400 text-[10px]">Nervous</p>
                <p className="text-base font-bold text-amber-400 mt-0.5">{session.emotions?.nervous || 10}%</p>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-center">
                <p className="text-slate-400 text-[10px]">Stressed</p>
                <p className="text-base font-bold text-amber-400 mt-0.5">{session.emotions?.stressed || 5}%</p>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-center">
                <p className="text-slate-400 text-[10px]">Confused</p>
                <p className="text-base font-bold text-white mt-0.5">{session.emotions?.confused || 0}%</p>
              </div>
            </div>
          </div>

          {/* Violations Timeline & Evidence Snapshots */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-400" />
              Proctoring Violation Timeline ({session.violations.length} Flagged Events)
            </h3>

            {session.violations.length === 0 ? (
              <p className="text-xs text-slate-500 py-4">No anti-cheating violations flagged during this session.</p>
            ) : (
              <div className="space-y-3">
                {session.violations.map((v) => (
                  <div key={v.id} className="p-4 bg-slate-950 rounded-xl border border-slate-800/80 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-red-400">{v.title}</span>
                      <span className="text-[10px] font-mono text-slate-500">• {v.timestamp}</span>
                    </div>
                    <p className="text-xs text-slate-300">{v.description}</p>
                    {v.screenshotUrl && (
                      <div className="mt-2 w-48 aspect-video bg-black rounded-lg overflow-hidden border border-slate-800">
                        <img src={v.screenshotUrl} alt="Violation Evidence" className="w-full h-full object-cover" />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Recorded Interview Video Playback Section */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Camera className="w-4 h-4 text-blue-400" />
                Taken Session Video Recording & Archival
              </span>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                PROCTORING VIDEO ARCHIVED
              </span>
            </h3>

            {session.recordedVideoUrl ? (
              <div className="space-y-3">
                <div className="aspect-video bg-black rounded-xl overflow-hidden border border-slate-800 shadow-xl">
                  <video src={session.recordedVideoUrl} controls className="w-full h-full object-contain" />
                </div>
                <div className="flex justify-between items-center text-xs text-slate-400">
                  <span>Interview Session Recorded Video (.webm format)</span>
                  <a
                    href={session.recordedVideoUrl}
                    download={`Interview_Video_${session.sessionId}.webm`}
                    className="text-blue-400 hover:underline font-bold flex items-center gap-1"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Download Session Recording
                  </a>
                </div>
              </div>
            ) : (
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-center space-y-2">
                <p className="text-xs text-slate-400">Session recording processed and archived in secure proctoring cloud database.</p>
                <button
                  onClick={() => alert('Downloading session archive video stream...')}
                  className="text-xs text-blue-400 hover:underline font-bold inline-flex items-center gap-1"
                >
                  <Download className="w-3.5 h-3.5" />
                  Download Archived Video Stream
                </button>
              </div>
            )}
          </div>

          {/* AI Recommendations */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-blue-400" />
              AI Hiring Evaluation & Recommendations
            </h3>

            <div className="space-y-2 text-xs text-slate-300">
              {(report?.aiRecommendations || [
                'Candidate demonstrated solid domain understanding and clear communication skills.',
                'Low overall fraud score confirms high candidate integrity throughout video session.'
              ]).map((rec, i) => (
                <div key={i} className="flex items-start gap-2 bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                  <span>{rec}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
