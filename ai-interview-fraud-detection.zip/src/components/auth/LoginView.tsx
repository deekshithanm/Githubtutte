import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { ShieldCheck, Lock, Mail, Eye, EyeOff, RefreshCw, Sparkles, AlertCircle, CheckCircle2, Video, ArrowRight } from 'lucide-react';

interface LoginViewProps {
  onJoinWithCode?: (code: string) => void;
}

export const LoginView: React.FC<LoginViewProps> = ({ onJoinWithCode }) => {
  const { login } = useAuth();
  
  const [meetingCodeInput, setMeetingCodeInput] = useState('');
  const [email, setEmail] = useState('deekshagowda602@gmail.com');
  const [password, setPassword] = useState('deeksha@12');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  
  // CAPTCHA State
  const [num1, setNum1] = useState(7);
  const [num2, setNum2] = useState(5);
  const [captchaInput, setCaptchaInput] = useState('12');
  
  const [errorMessage, setErrorMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [loginAttempts, setLoginAttempts] = useState(0);

  // Forgot Password Modal State
  const [isForgotModalOpen, setIsForgotModalOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [otpStep, setOtpStep] = useState<'REQUEST' | 'VERIFY'>('REQUEST');
  const [otpCode, setOtpCode] = useState('');
  const [simulatedReceivedOtp, setSimulatedReceivedOtp] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [resetSuccessMessage, setResetSuccessMessage] = useState('');

  const generateCaptcha = () => {
    const n1 = Math.floor(Math.random() * 9) + 1;
    const n2 = Math.floor(Math.random() * 9) + 1;
    setNum1(n1);
    setNum2(n2);
    setCaptchaInput('');
  };

  const handleQuickPrefill = (role: 'admin' | 'interviewer' | 'candidate') => {
    if (role === 'admin') {
      setEmail('deekshagowda602@gmail.com');
      setPassword('deeksha@12');
    } else if (role === 'interviewer') {
      setEmail('interviewer@company.com');
      setPassword('interviewer123');
    } else {
      setEmail('alex.rivera@gmail.com');
      setPassword('candidate123');
    }
    setCaptchaInput(String(num1 + num2));
    setErrorMessage('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (loginAttempts >= 5) {
      setErrorMessage('Account locked due to multiple failed login attempts. Please wait 30 seconds.');
      return;
    }

    // CAPTCHA check
    if (parseInt(captchaInput) !== num1 + num2) {
      setErrorMessage('Incorrect CAPTCHA verification response. Please calculate again.');
      generateCaptcha();
      return;
    }

    setIsLoading(true);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email,
          password,
          captchaAnswer: captchaInput,
          captchaExpected: num1 + num2,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setLoginAttempts((prev) => prev + 1);
        throw new Error(data.message || 'Login failed.');
      }

      login(data.token, data.user);
    } catch (err: any) {
      setErrorMessage(err.message || 'Authentication error.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMessage('');

    try {
      const res = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: forgotEmail }),
      });
      const data = await res.json();
      
      if (!res.ok) throw new Error(data.message);

      setSimulatedReceivedOtp(data.otpCode);
      setOtpStep('VERIFY');
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to send OTP.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyOtpAndReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMessage('');

    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: forgotEmail, otp: otpCode, newPassword }),
      });
      const data = await res.json();

      if (!res.ok) throw new Error(data.message);

      setResetSuccessMessage('Password reset successfully! Please log in with your new password.');
      setTimeout(() => {
        setIsForgotModalOpen(false);
        setOtpStep('REQUEST');
        setResetSuccessMessage('');
      }, 2000);
    } catch (err: any) {
      setErrorMessage(err.message || 'OTP reset failed.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-center items-center p-4 relative overflow-hidden">
      {/* Ambient background glow */}
      <div className="absolute -top-40 -left-40 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none" />

      {/* Header Branding */}
      <div className="text-center mb-8 z-10 max-w-md">
        <div className="inline-flex items-center justify-center p-3 bg-blue-600/10 border border-blue-500/20 rounded-2xl mb-4 text-blue-400">
          <ShieldCheck className="w-10 h-10" />
        </div>
        <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-white via-slate-200 to-slate-400 bg-clip-text text-transparent">
          AI Interview Monitor
        </h1>
        <p className="text-slate-400 text-sm mt-2">
          Enterprise Real-Time AI Proctoring & Anti-Cheating Video Platform
        </p>
      </div>

      {/* Main Login Card */}
      <div className="w-full max-w-md bg-slate-900/80 backdrop-blur-xl border border-slate-800 rounded-2xl p-8 shadow-2xl z-10 space-y-6">
        {/* Portal Switcher Tabs */}
        <div>
          <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-blue-400" />
            Select Access Portal
          </label>
          <div className="grid grid-cols-3 gap-1.5 bg-slate-950 p-1.5 rounded-xl border border-slate-800">
            <button
              type="button"
              onClick={() => handleQuickPrefill('admin')}
              className={`text-xs py-2 px-2 rounded-lg font-bold transition flex flex-col items-center gap-1 cursor-pointer ${
                email === 'deekshagowda602@gmail.com'
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>Admin</span>
              <span className="text-[9px] font-normal opacity-80">Full Access</span>
            </button>
            <button
              type="button"
              onClick={() => handleQuickPrefill('interviewer')}
              className={`text-xs py-2 px-2 rounded-lg font-bold transition flex flex-col items-center gap-1 cursor-pointer ${
                email === 'interviewer@company.com'
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>Interviewer</span>
              <span className="text-[9px] font-normal opacity-80">Conduct Sessions</span>
            </button>
            <button
              type="button"
              onClick={() => handleQuickPrefill('candidate')}
              className={`text-xs py-2 px-2 rounded-lg font-bold transition flex flex-col items-center gap-1 cursor-pointer ${
                email === 'alex.rivera@gmail.com'
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>Candidate</span>
              <span className="text-[9px] font-normal opacity-80">Take Test</span>
            </button>
          </div>
        </div>

        {errorMessage && (
          <div className="mb-4 p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Email input */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="deekshagowda602@gmail.com"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 pl-10 pr-4 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition"
              />
            </div>
          </div>

          {/* Password input */}
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label className="block text-xs font-medium text-slate-300">
                Password
              </label>
              <button
                type="button"
                onClick={() => {
                  setForgotEmail(email);
                  setIsForgotModalOpen(true);
                }}
                className="text-xs text-blue-400 hover:text-blue-300 transition"
              >
                Forgot password?
              </button>
            </div>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 pl-10 pr-10 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-3 text-slate-500 hover:text-slate-300"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* CAPTCHA verification */}
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400 font-mono bg-slate-900 py-1.5 px-3 rounded-lg border border-slate-800 font-bold text-white tracking-widest">
                {num1} + {num2} = ?
              </span>
              <button
                type="button"
                onClick={generateCaptcha}
                title="Refresh CAPTCHA"
                className="text-slate-500 hover:text-white p-1 transition"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
            </div>
            <input
              type="text"
              required
              value={captchaInput}
              onChange={(e) => setCaptchaInput(e.target.value)}
              placeholder="Answer"
              className="w-24 bg-slate-900 border border-slate-800 rounded-lg py-1.5 px-3 text-xs text-center text-white focus:outline-none focus:border-blue-500"
            />
          </div>

          {/* Remember me */}
          <div className="flex items-center">
            <input
              type="checkbox"
              id="remember"
              checked={rememberMe}
              onChange={(e) => setRememberMe(e.target.checked)}
              className="w-4 h-4 rounded border-slate-800 bg-slate-950 text-blue-600 focus:ring-blue-500"
            />
            <label htmlFor="remember" className="ml-2 text-xs text-slate-400">
              Remember session for 30 days
            </label>
          </div>

          {/* Submit button */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-blue-600 hover:bg-blue-500 text-white font-medium py-2.5 rounded-xl text-sm transition shadow-lg shadow-blue-600/20 disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {isLoading ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              'Sign In to Dashboard'
            )}
          </button>
        </form>

        <div className="mt-6 pt-4 border-t border-slate-800 text-center text-xs text-slate-500">
          Secured with Bcrypt & JWT Encryption • Role-Based Control
        </div>
      </div>

      {/* Forgot Password OTP Modal */}
      {isForgotModalOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 w-full max-w-md shadow-2xl relative">
            <h3 className="text-lg font-bold text-white mb-2">Reset Password with OTP</h3>
            <p className="text-xs text-slate-400 mb-4">
              {otpStep === 'REQUEST'
                ? 'Enter your account email to receive a 6-digit verification OTP.'
                : `OTP sent to ${forgotEmail}. Check simulated code below.`}
            </p>

            {resetSuccessMessage && (
              <div className="mb-4 p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-400 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4" />
                <span>{resetSuccessMessage}</span>
              </div>
            )}

            {otpStep === 'REQUEST' ? (
              <form onSubmit={handleSendOtp} className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    required
                    value={forgotEmail}
                    onChange={(e) => setForgotEmail(e.target.value)}
                    placeholder="deekshagowda602@gmail.com"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2 px-3 text-sm text-white"
                  />
                </div>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setIsForgotModalOpen(false)}
                    className="flex-1 bg-slate-800 text-slate-300 text-xs py-2 rounded-xl"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="flex-1 bg-blue-600 hover:bg-blue-500 text-white text-xs py-2 rounded-xl"
                  >
                    Send Reset OTP
                  </button>
                </div>
              </form>
            ) : (
              <form onSubmit={handleVerifyOtpAndReset} className="space-y-4">
                {simulatedReceivedOtp && (
                  <div className="p-2.5 bg-blue-500/10 border border-blue-500/20 rounded-xl text-xs text-blue-300 flex items-center justify-between">
                    <span>Simulated OTP Mail Code:</span>
                    <span className="font-mono font-bold text-white text-sm tracking-wider bg-slate-950 px-2 py-0.5 rounded border border-blue-500/30">
                      {simulatedReceivedOtp}
                    </span>
                  </div>
                )}
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    6-Digit OTP Code
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value)}
                    placeholder="Enter code"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2 px-3 text-sm text-center font-mono text-white tracking-widest"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    New Password
                  </label>
                  <input
                    type="password"
                    required
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2 px-3 text-sm text-white"
                  />
                </div>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setOtpStep('REQUEST')}
                    className="flex-1 bg-slate-800 text-slate-300 text-xs py-2 rounded-xl"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="flex-1 bg-blue-600 hover:bg-blue-500 text-white text-xs py-2 rounded-xl"
                  >
                    Update Password
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
