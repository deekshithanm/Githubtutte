// Real-Time WebSocket Client Manager

type MessageCallback = (data: any) => void;

class SocketClient {
  private ws: WebSocket | null = null;
  private listeners: Set<MessageCallback> = new Set();
  private isConnected = false;
  private currentInterviewId: string | null = null;
  private currentRole: string = 'anonymous';

  connect() {
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      return;
    }

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    this.ws = new WebSocket(wsUrl);

    this.ws.onopen = () => {
      this.isConnected = true;
      console.log('[WebSocket] Connected to AI Interview Monitor server');
      if (this.currentInterviewId) {
        this.subscribe(this.currentInterviewId, this.currentRole);
      }
    };

    this.ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        this.listeners.forEach((callback) => callback(data));
      } catch (err) {
        console.error('[WebSocket] Failed to parse message', err);
      }
    };

    this.ws.onclose = () => {
      this.isConnected = false;
      console.log('[WebSocket] Connection closed. Retrying in 3s...');
      setTimeout(() => this.connect(), 3000);
    };

    this.ws.onerror = (err) => {
      console.error('[WebSocket] Error', err);
    };
  }

  subscribe(interviewId: string, role: string) {
    this.currentInterviewId = interviewId;
    this.currentRole = role;
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(
        JSON.stringify({
          type: 'subscribe',
          interviewId,
          role,
        })
      );
    }
  }

  sendSignal(interviewId: string, signalData: any) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(
        JSON.stringify({
          type: 'webrtc_signal',
          interviewId,
          signal: signalData,
        })
      );
    }
  }

  sendJoinRequest(interviewId: string, candidateName: string, candidateId: string) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(
        JSON.stringify({
          type: 'join_request',
          interviewId,
          candidateName,
          candidateId,
        })
      );
    }
  }

  sendAdmitCandidate(interviewId: string, candidateId: string) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(
        JSON.stringify({
          type: 'admit_candidate',
          interviewId,
          candidateId,
        })
      );
    }
  }

  sendDenyCandidate(interviewId: string, candidateId: string) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(
        JSON.stringify({
          type: 'deny_candidate',
          interviewId,
          candidateId,
        })
      );
    }
  }

  sendChatMessage(interviewId: string, message: { id: string; sender: string; text: string; time: string }) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(
        JSON.stringify({
          type: 'chat_message',
          interviewId,
          message,
        })
      );
    }
  }

  sendMediaState(interviewId: string, mediaState: { role: string; cameraOn: boolean; micOn: boolean }) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(
        JSON.stringify({
          type: 'media_state',
          interviewId,
          mediaState,
        })
      );
    }
  }

  sendVideoFrame(interviewId: string, role: string, frameDataUrl: string) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(
        JSON.stringify({
          type: 'video_frame',
          interviewId,
          role,
          frameDataUrl,
        })
      );
    }
  }

  sendViolation(interviewId: string, violation: any) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(
        JSON.stringify({
          type: 'violation',
          interviewId,
          violation,
        })
      );
    }
  }

  sendMetricsUpdate(interviewId: string, metrics: any) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(
        JSON.stringify({
          type: 'metrics_update',
          interviewId,
          metrics,
        })
      );
    }
  }

  sendTranscriptAppend(interviewId: string, segment: any) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(
        JSON.stringify({
          type: 'transcript_append',
          interviewId,
          segment,
        })
      );
    }
  }

  addListener(callback: MessageCallback) {
    this.listeners.add(callback);
    return () => this.listeners.delete(callback);
  }
}

export const socketClient = new SocketClient();
